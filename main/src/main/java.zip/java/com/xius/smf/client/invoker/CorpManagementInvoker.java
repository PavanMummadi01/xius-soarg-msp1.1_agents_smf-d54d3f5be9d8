/***********************************************
 * Company XIUS-BCGI (Megasoft Pvt Ltd Hyderabad,INDIA)
 * � Copyright 2015 MEGASOFT.
 *
 * Package        : com.xius.mspgw.client.invoker
 * Name of File   : SubscriberManagementInvoker
 * $DateTime: 2023/09/20 17:37:16 $Change:  $
 * @author naveen.aalone $Author: shashidhar.p $
 * Description    : This is used to make XBUS call to get SubscriberDetails
 * 					
 *
 * Method names   : getSubscriberServices()
 * 					
 * 
 * Modifications
 * Method Name  |  Date   |  Author  | Explanation
 * -------------------------------------------------------------              
 *              |         |          |
 *              |         |          | 
 *             
 *****************************************************/
package com.xius.smf.client.invoker;
import java.net.MalformedURLException;
import java.net.URL;
import java.rmi.RemoteException;

import net.bcgi.common.jmon.monitor.BCGLevel;
import net.bcgi.common.jmon.monitor.BCGLogger;

import org.apache.axis.AxisFault;
import org.apache.axis.message.SOAPHeaderElement;

import com.xius.smf.exceptions.SMFAgentException;
import com.xius.smf.utils.HeaderDetails;
import com.xius.smf.utils.InitiateAll;
import com.xius.smf.utils.SMFAgentConstants;
import com.xius.smf.utils.Utilities;
import com.xiusbcgi.xbus.scare.CorpManagement_wsdl.CorpManagementServicesBindingStub;
import com.xiusbcgi.xbus.scare.CorpManagement_wsdl.CorpManagementServicesLocator;
import com.xiusbcgi.xbus.scare.CorpManagement_xsd.GetAccountRequest;
import com.xiusbcgi.xbus.scare.CorpManagement_xsd.GetAccountResponse;
import com.xiusbcgi.xbus.scare.common.error.ErrorDetails_xsd.ErrorDetailsType;

public class CorpManagementInvoker {
	
	private static final BCGLogger logger = BCGLogger.getBCGLogger(CorpManagementInvoker.class.getSimpleName());

	public GetAccountResponse getAccountInfo(HeaderDetails headerDetails, String request ) throws  SMFAgentException{
		long startTime= System.currentTimeMillis();
		long endTime= 0;
		
		String url = InitiateAll.getSMFProps().getProperty("selfcare.corpManagement");
		logger.log(BCGLevel.INFO, " URL for calling SelfcareServ getAccountInfo : "+url);
		GetAccountRequest accRequest = new GetAccountRequest();
		GetAccountResponse accResponse = new GetAccountResponse();
		CorpManagementServicesBindingStub corpMgmntStub = null;
		try {
			corpMgmntStub = new CorpManagementServicesBindingStub(new URL(url),new CorpManagementServicesLocator());
			//setting SOAP Header
			headerDetails.setRequestID("1");
			SOAPHeaderElement header = Utilities.getSelfCareSoapHeader(headerDetails);
			corpMgmntStub.setHeader(header);
			
			//setting up the time out
			corpMgmntStub.setTimeout(Integer.parseInt(InitiateAll.getSMFProps().getProperty("selfcare.timeout")));
			accRequest.setMSISDN(request);
			logger.log(BCGLevel.INFO, "<<<Calling SelfcareServ to getAccountInfo  : MSISDN : " + request);
		
			accResponse = corpMgmntStub.getAccount(accRequest);
			
			logger.log(BCGLevel.INFO, "AccountId: "+accResponse.getAccountId());
			logger.log(BCGLevel.INFO, "MSISDN: "+accResponse.getMSISDN());
			logger.log(BCGLevel.INFO, "SIM: "+accResponse.getSIM());
			logger.log(BCGLevel.INFO, "IMSNumber: "+accResponse.getIMSI());
			logger.log(BCGLevel.INFO, "AccountStatus: "+accResponse.getAccountStatus());
			logger.log(BCGLevel.INFO, "AccountType: "+accResponse.getAcctType());
			logger.log(BCGLevel.INFO, "OfficeCode: "+accResponse.getOfficeCode());
			
			if(accResponse != null){
				logger.log(BCGLevel.INFO, ">>>Response from getAccountInfo, AccountId: " + accResponse.getAccountId());
				endTime = System.currentTimeMillis();
				logger.log(BCGLevel.INFO,"getAccountInfo Success:"+(int) (endTime - startTime)+"ms");
				
			}else{
				logger.log(BCGLevel.ERROR,"No response from SelfcareServ for getAccountInfo api..");
				endTime = System.currentTimeMillis();
				logger.log(BCGLevel.INFO,"getAccountInfo Failure:"+(int) (endTime - startTime)+"ms");
				throw new SMFAgentException(SMFAgentConstants.INTERNAL_ERROR_CODE, null);
			}
		} 
		catch(ErrorDetailsType e){
			logger.log(BCGLevel.ERROR, "CorpManagementInvoker - ErrorDetailsType ErroCode:"+e.getErrorCode());
			logger.log(BCGLevel.ERROR, "CorpManagementInvoker - ErrorDetailsType ErrorMessage:"+e.getErrorMessage());
			endTime = System.currentTimeMillis();
			logger.log(BCGLevel.INFO,"CorpManagementInvoker Failure:"+(int) (endTime - startTime)+"ms");
			throw new SMFAgentException(e.getErrorCode(), null);			
		}catch (AxisFault e) {
			logger.log(BCGLevel.ERROR, "getAccountInfo - AxisFault :"+Utilities.getStackTrace(e));
			endTime = System.currentTimeMillis();
			logger.log(BCGLevel.INFO,"getAccountInfo Failure:"+(int) (endTime - startTime)+"ms");
			throw new SMFAgentException(SMFAgentConstants.INTERNAL_ERROR_CODE, null);
		} catch (RemoteException e) {
			logger.log(BCGLevel.ERROR, "getAccountInfo - RemoteException:"+Utilities.getStackTrace(e));
			endTime = System.currentTimeMillis();
			logger.log(BCGLevel.INFO,"getAccountInfo Failure:"+(int) (endTime - startTime)+"ms");
			throw new SMFAgentException(SMFAgentConstants.INTERNAL_ERROR_CODE, null);
		} catch (MalformedURLException e) {
			logger.log(BCGLevel.ERROR, "getAccountInfo - MalformedURLException :"+Utilities.getStackTrace(e));
			endTime = System.currentTimeMillis();
			logger.log(BCGLevel.INFO,"getUsage Failure:"+(int) (endTime - startTime)+"ms");
			throw new SMFAgentException(SMFAgentConstants.INTERNAL_ERROR_CODE, null);
		}		
		return accResponse;
	}
}