package com.xius.smf.job;

import net.bcgi.common.jmon.monitor.BCGLevel;
import net.bcgi.common.jmon.monitor.BCGLogger;
import net.bcgi.util.db.SPFactory;

import com.xius.smf.domaindata.CAGroupDtlsUpdateData;
import com.xius.smf.utils.ServiceUtils;
import com.xius.smf.utils.Utilities;

public class CAGroupDtlsUpdateProcessor {
	private static final BCGLogger logger = BCGLogger.getBCGLogger(CAGroupDtlsUpdateProcessor.class.getSimpleName());

	public void statusUpdate(CAGroupDtlsUpdateData domainData)throws Exception {
		
		 
		SPFactory factory = ServiceUtils.executeSPWithOutCommit("pro_ca_group_dtls_update", domainData, domainData);

		if (logger.isInfoEnabled()) {
			logger.log(BCGLevel.INFO, domainData.toString());
		}

		Utilities.commitOrRollback(factory, domainData.getPo_error_code());

		if (logger.isInfoEnabled()) {
			logger.log(BCGLevel.INFO,"Error Code from pro_thiredparty_notific_update  ==>"+ domainData.getPo_error_code());
			logger.log(BCGLevel.INFO,"Error Msg from pro_thiredparty_notific_update  ==>"+ domainData.getPo_error_desc());
		}		
	}
	 
}
