package com.xius.smf.domaindata;

public class MDNRegActUpdateData extends DomainDataBase{
	
	private Long pi_trans_no;
	private String pi_msdn_status;
	private String pi_remarks;
	/**
	 * @return the pi_trans_no
	 */
	public Long getPi_trans_no() {
		return pi_trans_no;
	}
	/**
	 * @param pi_trans_no the pi_trans_no to set
	 */
	public void setPi_trans_no(Long pi_trans_no) {
		this.pi_trans_no = pi_trans_no;
	}
	/**
	 * @return the pi_msdn_status
	 */
	public String getPi_msdn_status() {
		return pi_msdn_status;
	}
	/**
	 * @param pi_msdn_status the pi_msdn_status to set
	 */
	public void setPi_msdn_status(String pi_msdn_status) {
		this.pi_msdn_status = pi_msdn_status;
	}
	/**
	 * @return the pi_remarks
	 */
	public String getPi_remarks() {
		return pi_remarks;
	}
	/**
	 * @param pi_remarks the pi_remarks to set
	 */
	public void setPi_remarks(String pi_remarks) {
		this.pi_remarks = pi_remarks;
	}
	
		 
  }
