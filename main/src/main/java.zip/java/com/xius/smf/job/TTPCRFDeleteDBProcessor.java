package com.xius.smf.job;

import net.bcgi.common.jmon.monitor.BCGLevel;
import net.bcgi.common.jmon.monitor.BCGLogger;
import net.bcgi.util.db.SPFactory;

import com.xius.smf.domaindata.TTPCRFDeleteDATA;
import com.xius.smf.utils.ServiceUtils;
import com.xius.smf.utils.Utilities;

public class TTPCRFDeleteDBProcessor  {
	
	private static final BCGLogger logger = BCGLogger
			.getBCGLogger(TTPCRFDeleteDBProcessor.class.getSimpleName());

	public void statusUpdate(TTPCRFDeleteDATA  Data)throws Exception {
		
		 
		SPFactory factory = ServiceUtils.executeSPWithOutCommit("delete_policy_tracker", Data, Data);

		if (logger.isInfoEnabled()) {
			logger.log(BCGLevel.INFO, Data.toString());
		}

		Utilities.commitOrRollback(factory, Data.getPo_error_code());

		if (logger.isInfoEnabled()) {
			logger.log(BCGLevel.INFO,"Error Code from delete_policy_tracker.xml  ==>"+ Data.getPo_error_code());
			logger.log(BCGLevel.INFO,"Error Msg from delete_policy_tracker.xml  ==>"+ Data.getPo_error_desc());
		}	
		
	}

}