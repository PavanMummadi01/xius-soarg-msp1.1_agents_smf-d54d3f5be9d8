/******************************************************************
 * Company XIUS (Megasoft Pvt Ltd Hyderabad,INDIA)
 * � Copyright 2006 MEGASOFT. 
 *
 * Package      : com.xius.mspgw.client.invoker;
 * Name of File : GetETNotificationInvoker.java
 * Date /Year   : Jun 26, 2018
 * Author       : shashidhar.p
 * Discription  : 
 *
 * Method names : 
 * 
 * Modifications
 * Method Name  |  Date   |  Author  | Explanation
 * -------------------------------------------------------------              
 *              |         |          |
 *              |         |          | 
 *             
 ********************************************************************/
package com.xius.smf.client.invoker;

import java.net.MalformedURLException;
import java.net.URL;
import java.rmi.RemoteException;

import net.bcgi.common.jmon.monitor.BCGLevel;
import net.bcgi.common.jmon.monitor.BCGLogger;

import org.apache.axis.AxisFault;
import org.apache.axis.message.SOAPHeaderElement;

import com.xius.billing.SubscriberManagement_wsdl.SubscriberManagementBindingStub;
import com.xius.billing.SubscriberManagement_wsdl.SubscriberServiceLocator;
import com.xius.billing.SubscriberManagement_xsd.GetETNotifInfoRequest;
import com.xius.billing.SubscriberManagement_xsd.GetETNotifInfoResponse;
import com.xius.billing.common.error.ErrorDetails_xsd.ErrorDetailsType;
import com.xius.smf.exceptions.SMFAgentException;
import com.xius.smf.utils.HeaderDetails;
import com.xius.smf.utils.InitiateAll;
import com.xius.smf.utils.SMFAgentConstants;
import com.xius.smf.utils.Utilities;

public class GetETNotificationInvoker {
	private static final BCGLogger logger = BCGLogger
			.getBCGLogger(GetETNotificationInvoker.class.getSimpleName());

	public GetETNotifInfoResponse GetETNotification(HeaderDetails headerDetails,
			GetETNotifInfoRequest Request) throws SMFAgentException {
		long startTime = System.currentTimeMillis();
		long endTime = 0;
		String url = InitiateAll.getSMFProps().getProperty("iba.SubscriberManagement");
		if (logger.isInfoEnabled()) {
			logger.info("the url for request" + url);
		}
		GetETNotifInfoResponse response = null;
		SubscriberManagementBindingStub bindingStub = null;
		try {
			bindingStub = new SubscriberManagementBindingStub(new URL(url),new SubscriberServiceLocator());
			SOAPHeaderElement header = Utilities.getSoapHeader(headerDetails);
			bindingStub.setHeader(header);

			bindingStub.setTimeout(Integer.parseInt(InitiateAll.getSMFProps().getProperty("iba.timeout")));

			response = bindingStub.getETNotifInfo(Request);

			if (response != null) {
				if (logger.isInfoEnabled()) {
					logger.log(BCGLevel.INFO,
							">>>Response from  GetETNotificationInvoker---> GetETNotification api getIsSendNotification : "
									+ response.getIsSendNotification());
					endTime = System.currentTimeMillis();
					logger.log(BCGLevel.INFO,
							" GetETNotificationInvoker--->Recharge Success:"
									+ (int) (endTime - startTime) + "ms");
				}
			} else {
				logger.log(BCGLevel.ERROR,
						"No response from IBA for GetETNotificationInvoker---> Recharge api..");
				endTime = System.currentTimeMillis();
				logger.log(BCGLevel.INFO,
						" GetETNotificationInvoker--->GetETNotificationInvoker Failure:"
								+ (int) (endTime - startTime) + "ms");
				throw new SMFAgentException(SMFAgentConstants.INTERNAL_ERROR_CODE_STR, null);
			}

		} catch (ErrorDetailsType e) {
			logger.log(BCGLevel.ERROR,
					" GetETNotificationInvoker--->GetETNotification - ErrorDetailsType ErroCode:"
							+ e.getErrorCode());
			logger.log(BCGLevel.ERROR,
					" GetETNotificationInvoker--->GetETNotification - ErrorDetailsType ErrorMessage:"
							+ e.getErrorMessage());
			endTime = System.currentTimeMillis();
			if (logger.isInfoEnabled()) {
				logger.log(BCGLevel.INFO,
						" GetETNotificationInvoker--->GetETNotification Failure:"
								+ (int) (endTime - startTime) + "ms");
			}
			throw new SMFAgentException(e.getErrorCode(), e.getErrorMessage());
		} catch (AxisFault e) {
			logger.log(BCGLevel.ERROR,
					" GetETNotificationInvoker--->GetETNotification- AxisFault :"
							+ Utilities.getStackTrace(e));
			endTime = System.currentTimeMillis();
			if (logger.isInfoEnabled()) {
				logger.log(BCGLevel.INFO,
						" GetETNotificationInvoker--->GetETNotification aFilure:"
								+ (int) (endTime - startTime) + "ms");
			}
			throw new SMFAgentException(SMFAgentConstants.INTERNAL_ERROR_CODE_STR,null);
		} catch (RemoteException e) {
			logger.log(BCGLevel.ERROR,
					"GetETNotificationInvoker--->GetETNotification - RemoteException:"
							+ Utilities.getStackTrace(e));
			endTime = System.currentTimeMillis();
			if (logger.isInfoEnabled()) {
				logger.log(BCGLevel.INFO,
						" GetETNotificationInvoker--->GetETNotification Failure:"
								+ (int) (endTime - startTime) + "ms");
			}
			throw new SMFAgentException(SMFAgentConstants.INTERNAL_ERROR_CODE_STR,null);
		} catch (MalformedURLException e) {
			logger.log(BCGLevel.ERROR,
					" GetETNotificationInvoker--->GetETNotification - MalformedURLException :"
							+Utilities.getStackTrace(e));
			endTime = System.currentTimeMillis();
			if (logger.isInfoEnabled()) {
				logger.log(BCGLevel.INFO,
						" GetETNotificationInvoker--->GetETNotification Failure:"
								+ (int) (endTime - startTime) + "ms");
			}
			throw new SMFAgentException(SMFAgentConstants.INTERNAL_ERROR_CODE_STR,null);
		}
		return response;
	}
}
