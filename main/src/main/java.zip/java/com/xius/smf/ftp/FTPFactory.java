package com.xius.smf.ftp;

import net.bcgi.common.jmon.monitor.BCGLogger;

public class FTPFactory {

	private static FTPProxy ftpProxy = null;

	static BCGLogger logger = BCGLogger.getBCGLogger("FTPProxy");

	private FTPFactory(){

	}

	public static FTPProxy getInstance(){
		
		if( null == ftpProxy ) {
			
			ftpProxy = FTPProxy.getInstance();
		}
		
		return ftpProxy;
	}
}
