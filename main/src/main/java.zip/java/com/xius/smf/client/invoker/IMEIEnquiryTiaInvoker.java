/******************************************************************
 * Company XIUS (Megasoft Pvt Ltd Hyderabad,INDIA)
 * � Copyright 2006 MEGASOFT. 
 *
 * Package      : com.xius.mspgw.client.invoker;
 * Name of File : ImeiEnquiryInvoker.java
 * Date /Year   : Oct 18, 2018
 * Author       : Shashidhar.P
 * Discription  : 
 *
 * Method names : 
 * 
 * Modifications
 * Method Name  |  Date   |  Author  | Explanation
 * -------------------------------------------------------------              
 *              |         |          |
 *              |         |          | 
 *             
 ********************************************************************/
package com.xius.smf.client.invoker;

import java.net.MalformedURLException;
import java.net.URL;
import java.rmi.RemoteException;

import javax.xml.soap.SOAPException;

import net.bcgi.common.jmon.monitor.BCGLevel;
import net.bcgi.common.jmon.monitor.BCGLogger;

import org.apache.axis.AxisFault;
import org.apache.axis.message.SOAPHeaderElement;

import com.xius.billing.common.error.ErrorDetails_xsd.ErrorDetailsType;
import com.xius.smf.exceptions.SMFAgentException;
import com.xius.smf.utils.HeaderDetails;
import com.xius.smf.utils.InitiateAll;
import com.xius.smf.utils.SMFAgentConstants;
import com.xius.smf.utils.Utilities;
import com.xius.tia.TIAManagement_wsdl.TIAManagementBindingStub;
import com.xius.tia.TIAManagement_wsdl.TIAManagementLocator;
import com.xius.tia.TIAManagement_xsd.IMEIEnquiryRequest; 
import com.xius.tia.TIAManagement_xsd.IMEIEnquiryResponse;

public class IMEIEnquiryTiaInvoker {
	private static final BCGLogger logger = BCGLogger
			.getBCGLogger(IMEIEnquiryTiaInvoker.class.getSimpleName());

	public IMEIEnquiryResponse ImeiEnquiry(HeaderDetails headerDetails,
			IMEIEnquiryRequest Request) throws SMFAgentException, SOAPException {
		long startTime = System.currentTimeMillis();
		long endTime = 0;
		String url = InitiateAll.getSMFProps().getProperty("TIA_URL");
		if (logger.isInfoEnabled()) {
			logger.info("the url for request" + url);
		}
		IMEIEnquiryResponse response = null;
		TIAManagementBindingStub bindingStub = null;
		try {
			bindingStub = new TIAManagementBindingStub(new URL(url),new TIAManagementLocator());
			SOAPHeaderElement header = Utilities.getTIASoapHeader(headerDetails);
			bindingStub.setHeader(header);

			bindingStub.setTimeout(Integer.parseInt(InitiateAll.getSMFProps().getProperty("iba.timeout")));

			response = bindingStub.IMEIEnquiry(Request);

			if (response != null) {
				if (logger.isInfoEnabled()) {
					 
					logger.log(BCGLevel.INFO,
							">>>Response from  ImeiEnquiryInvoker---> ImeiEnquiry api getResponseCode : "
									+ response.getResponseData().getResponsecode());
					logger.log(BCGLevel.INFO,
							">>>Response from  ImeiEnquiryInvoker---> ImeiEnquiry api getResponseDescription : "
									+ response.getResponseData().getRespdescription());
										
					endTime = System.currentTimeMillis();
					logger.log(BCGLevel.INFO,
							" ImeiEnquiryInvoker--->Recharge Success:"
									+ (int) (endTime - startTime) + "ms");
				}
			} else {
				logger.log(BCGLevel.ERROR,
						"No response from IBA for ImeiEnquiryInvoker---> ImeiEnquiry api..");
				endTime = System.currentTimeMillis();
				logger.log(BCGLevel.INFO,
						" ImeiEnquiryInvoker--->ImeiEnquiryInvoker Failure:"
								+ (int) (endTime - startTime) + "ms");
				throw new SMFAgentException(SMFAgentConstants.INTERNAL_ERROR_CODE_STR, null);
			}

		} catch (ErrorDetailsType e) {
			logger.log(BCGLevel.ERROR,
					" ImeiEnquiryInvoker--->ImeiEnquiry - ErrorDetailsType ErroCode:"
							+ e.getErrorCode());
			logger.log(BCGLevel.ERROR,
					" ImeiEnquiryInvoker--->ImeiEnquiry - ErrorDetailsType ErrorMessage:"
							+ e.getErrorMessage());
			endTime = System.currentTimeMillis();
			if (logger.isInfoEnabled()) {
				logger.log(BCGLevel.INFO,
						" ImeiEnquiryInvoker--->ImeiEnquiry Failure:"
								+ (int) (endTime - startTime) + "ms");
			}
			throw new SMFAgentException(e.getErrorCode(), e.getErrorMessage());
		} catch (AxisFault e) {
			logger.log(BCGLevel.ERROR,
					" ImeiEnquiryInvoker--->ImeiEnquiry- AxisFault :"
							+ Utilities.getStackTrace(e));
			endTime = System.currentTimeMillis();
			if (logger.isInfoEnabled()) {
				logger.log(BCGLevel.INFO,
						" ImeiEnquiryInvoker--->ImeiEnquiry aFilure:"
								+ (int) (endTime - startTime) + "ms");
			}
			throw new SMFAgentException(SMFAgentConstants.INTERNAL_ERROR_CODE_STR,null);
		} catch (RemoteException e) {
			logger.log(BCGLevel.ERROR,
					"ImeiEnquiryInvoker--->ImeiEnquiry - RemoteException:"
							+ Utilities.getStackTrace(e));
			endTime = System.currentTimeMillis();
			if (logger.isInfoEnabled()) {
				logger.log(BCGLevel.INFO,
						" ImeiEnquiryInvoker--->ImeiEnquiry Failure:"
								+ (int) (endTime - startTime) + "ms");
			}
			throw new SMFAgentException(SMFAgentConstants.INTERNAL_ERROR_CODE_STR,null);
		} catch (MalformedURLException e) {
			logger.log(BCGLevel.ERROR,
					" ImeiEnquiryInvoker--->ImeiEnquiry - MalformedURLException :"
							+Utilities.getStackTrace(e));
			endTime = System.currentTimeMillis();
			if (logger.isInfoEnabled()) {
				logger.log(BCGLevel.INFO,
						" ImeiEnquiryInvoker--->ImeiEnquiry Failure:"
								+ (int) (endTime - startTime) + "ms");
			}
			throw new SMFAgentException(SMFAgentConstants.INTERNAL_ERROR_CODE_STR,null);
		}
		return response;
	}
}
