package com.xius.smf.domaindata;

public class UpdateExternalDetailsData extends DomainDataBase {

	     
	      private Long pi_msisdn_no;
	      private String pi_sim_no ;
	      private String pi_id_value;
	      private Long pi_account_id;
	      private Long pi_imsi_no;
	      private Long  pi_network_id;
	      private String pi_partner_name;
	      private String pi_partner_id;
	      private String pi_status;
	      private String pi_reason;
	     private String  pi_extarnal_trans_id ;
	     
		public String getPi_extarnal_trans_id() {
			return pi_extarnal_trans_id;
		}
		public void setPi_extarnal_trans_id(String pi_extarnal_trans_id) {
			this.pi_extarnal_trans_id = pi_extarnal_trans_id;
		}
		public Long getPi_msisdn_no() {
			return pi_msisdn_no;
		}
		public void setPi_msisdn_no(Long pi_msisdn_no) {
			this.pi_msisdn_no = pi_msisdn_no;
		}
		public String getPi_sim_no() {
			return pi_sim_no;
		}
		public void setPi_sim_no(String pi_sim_no) {
			this.pi_sim_no = pi_sim_no;
		}
		public String getPi_id_value() {
			return pi_id_value;
		}
		public void setPi_id_value(String pi_id_value) {
			this.pi_id_value = pi_id_value;
		}
		public Long getPi_account_id() {
			return pi_account_id;
		}
		public void setPi_account_id(Long pi_account_id) {
			this.pi_account_id = pi_account_id;
		}
		public Long getPi_imsi_no() {
			return pi_imsi_no;
		}
		public void setPi_imsi_no(Long pi_imsi_no) {
			this.pi_imsi_no = pi_imsi_no;
		}
		public Long getPi_network_id() {
			return pi_network_id;
		}
		public void setPi_network_id(Long pi_network_id) {
			this.pi_network_id = pi_network_id;
		}
		public String getPi_partner_name() {
			return pi_partner_name;
		}
		public void setPi_partner_name(String pi_partner_name) {
			this.pi_partner_name = pi_partner_name;
		}
		public String getPi_partner_id() {
			return pi_partner_id;
		}
		public void setPi_partner_id(String pi_partner_id) {
			this.pi_partner_id = pi_partner_id;
		}
		public String getPi_status() {
			return pi_status;
		}
		public void setPi_status(String pi_status) {
			this.pi_status = pi_status;
		}
		public String getPi_reason() {
			return pi_reason;
		}
		public void setPi_reason(String pi_reason) {
			this.pi_reason = pi_reason;
		}
		
	    
}
