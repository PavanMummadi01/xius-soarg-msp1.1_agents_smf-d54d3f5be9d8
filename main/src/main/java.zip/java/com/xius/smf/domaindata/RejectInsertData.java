package com.xius.smf.domaindata;


 

public class RejectInsertData extends DomainDataBase {
	
	   private String pi_iccid;
	   private String pi_nir_code;
	   private String pi_trans_id;
	   private String pi_reject_code;
	   private String pi_reject_reason;
	   private Long pi_office_code;
	   
	/**
	 * @return the pi_iccid
	 */
	public String getPi_iccid() {
		return pi_iccid;
	}
	/**
	 * @param pi_iccid the pi_iccid to set
	 */
	public void setPi_iccid(String pi_iccid) {
		this.pi_iccid = pi_iccid;
	}
	/**
	 * @return the pi_nir_code
	 */
	public String getPi_nir_code() {
		return pi_nir_code;
	}
	/**
	 * @param pi_nir_code the pi_nir_code to set
	 */
	public void setPi_nir_code(String pi_nir_code) {
		this.pi_nir_code = pi_nir_code;
	}
	/**
	 * @return the pi_trans_id
	 */
	public String getPi_trans_id() {
		return pi_trans_id;
	}
	/**
	 * @param pi_trans_id the pi_trans_id to set
	 */
	public void setPi_trans_id(String pi_trans_id) {
		this.pi_trans_id = pi_trans_id;
	}
	/**
	 * @return the pi_reject_code
	 */
	public String getPi_reject_code() {
		return pi_reject_code;
	}
	/**
	 * @param pi_reject_code the pi_reject_code to set
	 */
	public void setPi_reject_code(String pi_reject_code) {
		this.pi_reject_code = pi_reject_code;
	}
	/**
	 * @return the pi_reject_reason
	 */
	public String getPi_reject_reason() {
		return pi_reject_reason;
	}
	/**
	 * @param pi_reject_reason the pi_reject_reason to set
	 */
	public void setPi_reject_reason(String pi_reject_reason) {
		this.pi_reject_reason = pi_reject_reason;
	}
	/**
	 * @param pi_office_code the pi_office_code to set
	 */
	public void setPi_office_code(Long pi_office_code) {
		this.pi_office_code = pi_office_code;
	}
	/**
	 * @return the pi_office_code
	 */
	public Long getPi_office_code() {
		return pi_office_code;
	}
	   
	   
	   
	   
	   
}
