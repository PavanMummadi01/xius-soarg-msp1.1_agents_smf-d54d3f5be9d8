package com.xius.smf.domaindata;


public class ViewForceSimActDetailsRefCursorData {
	
	private String force_sim_details;

	public String getForce_sim_details() {
		return force_sim_details;
	}

	public void setForce_sim_details(String force_sim_details) {
		this.force_sim_details = force_sim_details;
	}

	@Override
	public String toString() {
		return "ViewForceSimActDetailsRefCursorData [force_sim_details="
				+ force_sim_details + "]";
	}

	
	
}
