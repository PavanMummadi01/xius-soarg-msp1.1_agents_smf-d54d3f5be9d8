package com.xius.smf.job;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.StatefulJob;

public class StateChangeExpiryRetryJob implements Job,StatefulJob {

	
	public void execute(JobExecutionContext arg0) throws JobExecutionException {
	
		
		
		
		
		
		
		
	}
	
	
	
	
	

}
