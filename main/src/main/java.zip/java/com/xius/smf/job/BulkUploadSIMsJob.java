package com.xius.smf.job;

import net.bcgi.common.jmon.monitor.BCGLevel;
import net.bcgi.common.jmon.monitor.BCGLogger;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.StatefulJob;



import com.xius.smf.job.task.BulkUploadSIMSTask;
import com.xius.smf.utils.Utilities;

public class BulkUploadSIMsJob implements Job , StatefulJob {
	

		final BCGLogger logger = BCGLogger.getBCGLogger("BulkUploadSIMsJob");
		public void execute(JobExecutionContext executionContext) throws JobExecutionException {
			
			long start = System.currentTimeMillis();
			logger.log(BCGLevel.INFO,"=========== BulkUploadSIMSJob Started ===========");
			try {
				
				BulkUploadSIMSTask task = new BulkUploadSIMSTask();
				task.doJob();
			} catch (Exception e) {

				logger.log(BCGLevel.ERROR,"Exception in BulkUploadSIMSJob execute() :"+Utilities.getStackTrace(e));
			} 
			
			logger.log(BCGLevel.INFO,"=========== BulkUploadSIMSJob Ended ===========");
			logger.log(BCGLevel.INFO,"### ### ### Total Time taken to execute BulkUploadSIMSJob in (milli secons): " + (System.currentTimeMillis() - start)  );
		}
	}


