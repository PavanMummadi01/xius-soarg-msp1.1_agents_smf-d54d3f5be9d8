package com.xius.smf.domaindata;

public class GetLanguagesCursorData {
	
    private String   language_desc;
    private Integer   language_id;
    
	public String getLanguage_desc() {
		return language_desc;
	}
	public void setLanguage_desc(String language_desc) {
		this.language_desc = language_desc;
	}
	public Integer getLanguage_id() {
		return language_id;
	}
	public void setLanguage_id(Integer language_id) {
		this.language_id = language_id;
	}
}
