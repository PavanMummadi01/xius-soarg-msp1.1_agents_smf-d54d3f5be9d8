package com.xius.smf.domaindata;

public class APITrackerData extends DomainDataBase {
	
	private String channel;
	private String apiName;
	public String getChannel() {
		return channel;
	}
	public void setChannel(String channel) {
		this.channel = channel;
	}
	public String getApiName() {
		return apiName;
	}
	public void setApiName(String apiName) {
		this.apiName = apiName;
	}
	
	
	
	
}
