package com.xius.smf.client.ws;

import java.net.MalformedURLException;
import java.net.URL;
import java.rmi.RemoteException;

import javax.xml.rpc.ServiceException;

import net.bcgi.common.jmon.monitor.BCGLevel;
import net.bcgi.common.jmon.monitor.BCGLogger;
import net.bcgi.si.messages.mvnoapi.provisioning.PostpaidActivationRequest;
import net.bcgi.si.messages.mvnoapi.provisioning.PostpaidActivationResponse;
import net.bcgi.si.messages.mvnoapi.provisioning.PrepaidActivationRequest;
import net.bcgi.si.messages.mvnoapi.provisioning.PrepaidActivationResponse;
import net.bcgi.si.messages.mvnoapi.provisioning.UpdateSubDemographicDetailsRequest;
import net.bcgi.si.messages.mvnoapi.provisioning.UpdateSubDemographicDetailsResponse;
import soap_binding.servicemix.IProvisioningAppLocator;
import soap_binding.servicemix.IProvisioningAppPortType;

import com.xius.smf.utils.InitiateAll;

public class XBusProvisiongAppClient {

	//private BCGLogger logger = BCGLogger.getBCGLogger("XBusProvisiongAppClient");
	private BCGLogger logger = BCGLogger.getBCGLogger(this.getClass().getName());

	IProvisioningAppPortType porttype = null;

	public XBusProvisiongAppClient() throws MalformedURLException, ServiceException, InstantiationException {

		String xBusURL=InitiateAll.getSMFProps().getProperty( "provisioning.app.url");
		IProvisioningAppLocator locator = new IProvisioningAppLocator();

		porttype = locator.getProvisioningApp(new URL(xBusURL.trim()));

		if( null == porttype ) {

			throw new InstantiationException("Instance of IProvisioningAppPortType is null");
		}
	}

	public PrepaidActivationResponse prePaidActivation(PrepaidActivationRequest request) 
			throws RemoteException{

		long startTime = System.currentTimeMillis();

		String SIM =request.getMsisdnInfo().getSimNumber();

		logger.log(BCGLevel.INFO, ">>> Sending request to xBus's prePaidActivation for SIM: " + SIM );

		PrepaidActivationResponse response = porttype.prepaidActivation( request );
		
		if( null != response ) {

			logger.log(BCGLevel.INFO, "<<< Recevied response from xBus's prePaidActivation for SIM: " + SIM +" Status Code: " + response.getStatusCode());
		}

		logger.log(BCGLevel.INFO, "### total time taken to Recevie xBus's prePaidActivation response for SIM : "+ SIM +" in milli secons : " + (System.currentTimeMillis() - startTime ));
		return response;
	}
	
	public UpdateSubDemographicDetailsResponse updateSubDemographicDetails(UpdateSubDemographicDetailsRequest request)
			throws RemoteException{
		
		long startTime = System.currentTimeMillis();
		
		String SIM =request.getIccId();
		
		logger.log(BCGLevel.INFO, ">>> Sending request to xBus's updateSubDemographicDetails for SIM: " + SIM );
		
		UpdateSubDemographicDetailsResponse response = porttype.updateSubDemographicDetails( request );
		
		if( null != response ) {
		
			logger.log(BCGLevel.INFO, "<<< Recevied response from xBus's updateSubDemographicDetails for SIM: " + SIM +" Status Code: " + response.getStatusCode());
		}
		
		logger.log(BCGLevel.INFO, "### total time taken to Recevie xBus's updateSubDemographicDetails response for SIM : "+ SIM +" in milli secons : " + (System.currentTimeMillis() - startTime ));
		return response;
	}
	
	public PostpaidActivationResponse postPaidActivation(PostpaidActivationRequest request) 
			throws RemoteException{

		long startTime = System.currentTimeMillis();

		String SIM =request.getMsisdnInfo().getSimNumber();

		logger.log(BCGLevel.INFO, ">>> Sending request to xBus's postPaidActivation for SIM: " + SIM );

		PostpaidActivationResponse response = porttype.postpaidActivation( request );

		if( null != response ) {

			logger.log(BCGLevel.INFO, "<<< Recevied response from xBus's postPaidActivation for SIM: " + SIM +" Status Code: " + response.getStatusCode());
		}

		logger.log(BCGLevel.INFO, "### total time taken to Recevie xBus's postPaidActivation response for SIM : "+ SIM +" in milli secons : " + (System.currentTimeMillis() - startTime ));
		return response;
	}
}
