
package com.xius.smf.client.ws;

import java.rmi.RemoteException;

import org.apache.axis2.addressing.EndpointReference;

import net.bcgi.common.jmon.monitor.BCGLevel;
import net.bcgi.common.jmon.monitor.BCGLogger;
import com.xius.billing.balancemanagement_wsdl.BalanceServiceStub.SpecialTopUpResponse;
import com.xius.billing.balancemanagement_wsdl.BalanceServiceStub.DebitResponse;
import com.xius.billing.balancemanagement_wsdl.BalanceServiceStub;
import com.xius.billing.balancemanagement_wsdl.BalanceServiceStub.DebitRequestE;
import com.xius.billing.balancemanagement_wsdl.BalanceServiceStub.DebitResponseE;
import com.xius.billing.balancemanagement_wsdl.BalanceServiceStub.MessageHeader;
import com.xius.billing.balancemanagement_wsdl.BalanceServiceStub.SpecialTopUpRequestE;
import com.xius.billing.balancemanagement_wsdl.BalanceServiceStub.SpecialTopUpResponseE;
import com.xius.billing.balancemanagement_wsdl.BalanceServiceStub.TrackingMessageHeaderType;
import com.xius.billing.balancemanagement_wsdl.FaultMessage;
import com.xius.smf.utils.InitiateAll;
import com.xius.smf.utils.SMFAgentConstants;
import com.xius.smf.utils.Utilities;

/**
 * Class IBADebitWebserviceClient
 *
 *
 * @version        1.1, 16 Nov 2012
 * @author         Naveen Dasyam
 *
 */
public class IBAWebserviceClient {
    private static String    IBA_BAL_MGMT_URL      = null;
    private static BCGLogger logger              = BCGLogger.getBCGLogger("IBADebitWebserviceClient");

    static {
        //Properties SMFProp = InitiateAll.getSMFProps();

    	IBA_BAL_MGMT_URL = InitiateAll.getSMFProps().getProperty(SMFAgentConstants.IBA_BAL_MGMT_URL);
    }

    /**
     * Method invokeDebit
     *
     *
     * @param requestE
     * @param headerType
     *
     * @return DebitResponse
     */
    public DebitResponse invokeDebit(DebitRequestE requestE, TrackingMessageHeaderType headerType) {
        try {
        	DebitResponseE balResponse = null;

            if (logger.isInfoEnabled()) {
            	logger.log(BCGLevel.INFO, "Invoking IBA DebitRequest Service");
            }

            Long                startTime = System.currentTimeMillis();
            DebitResponse response  = null;
            MessageHeader       header    = new MessageHeader();

            header.setTrackingMessageHeader(headerType);

            EndpointReference                epr  = new EndpointReference(IBA_BAL_MGMT_URL);
            
            BalanceServiceStub stub = new BalanceServiceStub();

            stub._getServiceClient().getOptions().setTo(epr);

            if (logger.isInfoEnabled()) {
                logger.log(BCGLevel.INFO, ">>> Sending request to URL : " + IBA_BAL_MGMT_URL);
            }

            balResponse = stub.debit(requestE, header);

            // stub.notifyBalance (bal, authE);
            if (null != balResponse) {
                response = balResponse.getDebitResponse();
            }

            if (logger.isInfoEnabled()) {
                logger.log(BCGLevel.INFO,"webservice returned >> " + response.getCurrentBalance());
            }
            
            logger.logEvent("Debit success", (int) (System.currentTimeMillis() - startTime), "0000");

            return response;
            
        } catch (RemoteException e) {
            logger.log(BCGLevel.ERROR, "Exception in call IBA Service \n" + Utilities.getStackTrace(e));
            return null;
        } catch (FaultMessage e) {
            logger.log(BCGLevel.ERROR, "Exception in call IBA Service \n" + Utilities.getStackTrace(e));
            return null;
        }
    }
    
    /**
     * Method invokeSpecialTopUp
     *
     *
     * @param requestE
     * @param headerType
     *
     * @return SpecialTopUpResponse
     */
    public SpecialTopUpResponse invokeSpecialTopUp(SpecialTopUpRequestE requestE, TrackingMessageHeaderType headerType) {
    //public DebitResponse invokeService(DebitRequestE requestE, TrackingMessageHeaderType headerType) {
        try {
        	SpecialTopUpResponseE specialTopUpResponseE = null;

            if (logger.isInfoEnabled()) {
                logger.log(BCGLevel.INFO, "Invoking IBA SpecialTopUpRequest Service");
            }

            Long                startTime = System.currentTimeMillis();
            SpecialTopUpResponse response  = null;
            MessageHeader       header    = new MessageHeader();

            header.setTrackingMessageHeader(headerType);

            EndpointReference                epr  = new EndpointReference(IBA_BAL_MGMT_URL);
            
            BalanceServiceStub stub = new BalanceServiceStub();

            stub._getServiceClient().getOptions().setTo(epr);

            if (logger.isInfoEnabled()) {
                logger.log(BCGLevel.INFO, ">>> Sending request to URL : " + IBA_BAL_MGMT_URL);
            }

            specialTopUpResponseE = stub.specialTopUp(requestE, header);

            // stub.notifyBalance (bal, authE);
            if (null != specialTopUpResponseE) {
                response = specialTopUpResponseE.getSpecialTopUpResponse();
            }

            if (logger.isInfoEnabled()) {
                logger.log(BCGLevel.INFO,"webservice returned >> " + response.getCurrentBalance());
            }
            
            logger.logEvent("SpecialTopUp success", (int) (System.currentTimeMillis() - startTime), "0000");

            return response;
            
        } catch (RemoteException e) {
            logger.log(BCGLevel.ERROR, "Exception in call IBA Service \n" + Utilities.getStackTrace(e));
            return null;
        } catch (FaultMessage e) {
            logger.log(BCGLevel.ERROR, "Exception in call IBA Service \n" + Utilities.getStackTrace(e));
            return null;
        }
    }
}