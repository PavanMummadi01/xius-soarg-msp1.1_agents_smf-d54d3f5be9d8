package com.xius.smf.domaindata;

public class TTPCRFDeleteDATA extends DomainDataBase {

	private Long pi_transation_id;

	public void setPi_transation_id(Long pi_transation_id) {
		this.pi_transation_id = pi_transation_id;
	}

	public Long getPi_transation_id() {
		return pi_transation_id;
	}

}
