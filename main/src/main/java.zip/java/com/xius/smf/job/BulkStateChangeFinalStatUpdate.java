package com.xius.smf.job;

import net.bcgi.common.jmon.monitor.BCGLevel;
import net.bcgi.common.jmon.monitor.BCGLogger;
import net.bcgi.util.db.SPFactory;

import com.xius.smf.domaindata.BulkStateChangeUpdateData;
import com.xius.smf.utils.ServiceUtils;
import com.xius.smf.utils.Utilities;

public class BulkStateChangeFinalStatUpdate {
	private static final BCGLogger logger = BCGLogger.getBCGLogger(BulkStateChangeFinalStatUpdate.class.getSimpleName());

	public void statuUpdate(BulkStateChangeUpdateData domainData)throws Exception {
		
		 
		SPFactory factory = ServiceUtils.executeSPWithOutCommit("pro_state_change_upd", domainData, domainData);

		if (logger.isInfoEnabled()) {
			logger.log(BCGLevel.INFO, domainData.toString());
		}

		Utilities.commitOrRollback(factory, domainData.getPo_error_code());

		if (logger.isInfoEnabled()) {
			logger.log(BCGLevel.INFO,"Error Code from pro_state_change_upd  ==>"+ domainData.getPo_error_code());
			logger.log(BCGLevel.INFO,"Error Msg from pro_state_change_upd  ==>"+ domainData.getPo_error_desc());
		}		
	}
	 
}
