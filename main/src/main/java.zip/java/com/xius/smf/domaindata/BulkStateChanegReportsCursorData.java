package com.xius.smf.domaindata;

public class BulkStateChanegReportsCursorData {
	
	private String user_id;
	private String file_trans_id;
	private String file_status;
	private String transation_date;
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getFile_trans_id() {
		return file_trans_id;
	}
	public void setFile_trans_id(String file_trans_id) {
		this.file_trans_id = file_trans_id;
	}
	public String getFile_status() {
		return file_status;
	}
	public void setFile_status(String file_status) {
		this.file_status = file_status;
	}
	public String getTransation_date() {
		return transation_date;
	}
	public void setTransation_date(String transation_date) {
		this.transation_date = transation_date;
	}
	
	
}
