package com.xius.smf.job;

import net.bcgi.common.jmon.monitor.BCGLevel;
import net.bcgi.common.jmon.monitor.BCGLogger;
import net.bcgi.util.db.SPFactory;

import com.xius.smf.domaindata.TTPCRFUpdateDATA;
import com.xius.smf.utils.ServiceUtils;
import com.xius.smf.utils.Utilities;

public class TTPCRFUpdateProcessor  {
	
	private static final BCGLogger logger = BCGLogger
			.getBCGLogger(TTPCRFUpdateProcessor.class.getSimpleName());

	public void statusUpdate(TTPCRFUpdateDATA updatedData)throws Exception {
		
		 
		SPFactory factory = ServiceUtils.executeSPWithOutCommit("update_policy_tracker", updatedData, updatedData);

		if (logger.isInfoEnabled()) {
			logger.log(BCGLevel.INFO, updatedData.toString());
		}

		Utilities.commitOrRollback(factory, updatedData.getPo_error_code());

		if (logger.isInfoEnabled()) {
			logger.log(BCGLevel.INFO,"Error Code from update_policy_tracker  ==>"+ updatedData.getPo_error_code());
			logger.log(BCGLevel.INFO,"Error Msg from update_policy_tracker  ==>"+ updatedData.getPo_error_desc());
		}	
		
	}

}