package com.xius.smf.client.invoker;

import java.net.MalformedURLException;
import java.net.URL;
import java.rmi.RemoteException;

import javax.xml.rpc.ServiceException;

import net.bcgi.common.jmon.monitor.BCGLevel;
import net.bcgi.common.jmon.monitor.BCGLogger;

import org.apache.axis.AxisFault;
import org.apache.axis.message.SOAPHeaderElement;

import com.xius.billing.SubscriberManagement_wsdl.SubscriberManagementBindingStub;
import com.xius.billing.SubscriberManagement_wsdl.SubscriberServiceLocator;
import com.xius.billing.SubscriberManagement_xsd.FluValidationRequest;
import com.xius.billing.SubscriberManagement_xsd.FluValidationResponse;
import com.xius.billing.common.error.ErrorDetails_xsd.ErrorDetailsType;
import com.xius.smf.exceptions.SMFAgentException;
import com.xius.smf.utils.HeaderDetails;
import com.xius.smf.utils.InitiateAll;
import com.xius.smf.utils.SMFAgentConstants;
import com.xius.smf.utils.Utilities;

public class FluValidationInvoker {
	

	private static final BCGLogger logger = BCGLogger.getBCGLogger(FluValidationInvoker.class.getSimpleName());
	
	public FluValidationResponse fluValidation(
			FluValidationRequest request,HeaderDetails headerDetails) throws SMFAgentException, ServiceException {
		
		long startTime = System.currentTimeMillis();
		long endTime = 0;
		String url = InitiateAll.getSMFProps().getProperty("iba.SubscriberManagement");
		if (logger.isInfoEnabled()) {
			logger.info("the url for request" + url);
		}
		FluValidationResponse response = null;
		SubscriberManagementBindingStub bindingStub = null;
		try {
			bindingStub = new SubscriberManagementBindingStub(new URL(url),new SubscriberServiceLocator());
			SOAPHeaderElement header = Utilities.getSoapHeader(headerDetails);
			bindingStub.setHeader(header);

			bindingStub.setTimeout(Integer.parseInt(InitiateAll.getSMFProps().getProperty("iba.timeout")));

			response = bindingStub.fluValidation(request);

			if (response != null) {
				if (logger.isInfoEnabled()) {
					logger.log(BCGLevel.INFO,
							">>>Response from  FluValidationInvoker---> fluValidation api getMessage : "
									+ response.getMessage());
					endTime = System.currentTimeMillis();
					logger.log(BCGLevel.INFO,
							" FluValidationInvoker--->fluValidation Success:"
									+ (int) (endTime - startTime) + "ms");
				}
			} else {
				logger.log(BCGLevel.ERROR,
						"No response from IBA for FluValidationInvoker---> fluValidation api..");
				endTime = System.currentTimeMillis();
				logger.log(BCGLevel.INFO,
						" FluValidationInvoker--->fluValidation API Failure:"
								+ (int) (endTime - startTime) + "ms");
				throw new SMFAgentException(SMFAgentConstants.INTERNAL_ERROR_CODE_STR, null);
			}

		} catch (ErrorDetailsType e) {
			logger.log(BCGLevel.ERROR,
					" FluValidationInvoker--->fluValidation - ErrorDetailsType ErroCode:"
							+ e.getErrorCode());
			logger.log(BCGLevel.ERROR,
					" FluValidationInvoker--->fluValidation - ErrorDetailsType ErrorMessage:"
							+ e.getErrorMessage());
			endTime = System.currentTimeMillis();
			if (logger.isInfoEnabled()) {
				logger.log(BCGLevel.INFO,
						" FluValidationInvoker--->fluValidation Failure:"
								+ (int) (endTime - startTime) + "ms");
			}
			throw new SMFAgentException(e.getErrorCode(), e.getErrorMessage());
		} catch (AxisFault e) {
			logger.log(BCGLevel.ERROR,
					" FluValidationInvoker--->fluValidation- AxisFault :"
							+ Utilities.getStackTrace(e));
			endTime = System.currentTimeMillis();
			if (logger.isInfoEnabled()) {
				logger.log(BCGLevel.INFO,
						" FluValidationInvoker--->fluValidation aFilure:"
								+ (int) (endTime - startTime) + "ms");
			}
			throw new SMFAgentException(SMFAgentConstants.INTERNAL_ERROR_CODE_STR,null);
		} catch (RemoteException e) {
			logger.log(BCGLevel.ERROR,
					"FluValidationInvoker--->fluValidation - RemoteException:"
							+ Utilities.getStackTrace(e));
			endTime = System.currentTimeMillis();
			if (logger.isInfoEnabled()) {
				logger.log(BCGLevel.INFO,
						" FluValidationInvoker--->FluValidation Failure:"
								+ (int) (endTime - startTime) + "ms");
			}
			throw new SMFAgentException(SMFAgentConstants.INTERNAL_ERROR_CODE_STR,null);
		} catch (MalformedURLException e) {
			logger.log(BCGLevel.ERROR,
					" FluValidationInvoker--->fluValidation - MalformedURLException :"
							+Utilities.getStackTrace(e));
			endTime = System.currentTimeMillis();
			if (logger.isInfoEnabled()) {
				logger.log(BCGLevel.INFO,
						" FluValidationInvoker--->fluValidation Failure:"
								+ (int) (endTime - startTime) + "ms");
			}
			throw new SMFAgentException(SMFAgentConstants.INTERNAL_ERROR_CODE_STR,null);
		}
		return response;
	}
}