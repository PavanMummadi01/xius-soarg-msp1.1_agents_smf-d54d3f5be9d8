package com.xius.smf.domaindata;


public class Imei_file_dtls_cursor_dtls extends DomainDataBase {
	private Long network_id;
	private String user_id;
	private Long imei;
	private String action_status; 
	private String transreferencenumb;
	private String reason;
	private Long transation_id;
	private String transation_date;
	private String file_id;
	private String actual_reason;
	private String actuaal_log_time;
	private String comments;
	private String clarify_reason;
	private String source_of_request;
	
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public String getClarify_reason() {
		return clarify_reason;
	}
	public void setClarify_reason(String clarify_reason) {
		this.clarify_reason = clarify_reason;
	}
	public String getSource_of_request() {
		return source_of_request;
	}
	public void setSource_of_request(String source_of_request) {
		this.source_of_request = source_of_request;
	}
	public Long getNetwork_id() {
		return network_id;
	}
	public void setNetwork_id(Long network_id) {
		this.network_id = network_id;
	}
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public Long getImei() {
		return imei;
	}
	public void setImei(Long imei) {
		this.imei = imei;
	}
	public String getAction_status() {
		return action_status;
	}
	public void setAction_status(String action_status) {
		this.action_status = action_status;
	}
	public String getTransreferencenumb() {
		return transreferencenumb;
	}
	public void setTransreferencenumb(String transreferencenumb) {
		this.transreferencenumb = transreferencenumb;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	 
	public Long getTransation_id() {
		return transation_id;
	}
	public void setTransation_id(Long transation_id) {
		this.transation_id = transation_id;
	}
	public String getTransation_date() {
		return transation_date;
	}
	public void setTransation_date(String transation_date) {
		this.transation_date = transation_date;
	}
	public String getFile_id() {
		return file_id;
	}
	public void setFile_id(String file_id) {
		this.file_id = file_id;
	}
	public String getActual_reason() {
		return actual_reason;
	}
	public void setActual_reason(String actual_reason) {
		this.actual_reason = actual_reason;
	}
	public String getActuaal_log_time() {
		return actuaal_log_time;
	}
	public void setActuaal_log_time(String actuaal_log_time) {
		this.actuaal_log_time = actuaal_log_time;
	}
	



}
