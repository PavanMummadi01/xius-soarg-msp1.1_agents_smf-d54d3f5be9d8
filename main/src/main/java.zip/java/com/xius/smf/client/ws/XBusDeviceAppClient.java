package com.xius.smf.client.ws;

import java.net.MalformedURLException;
import java.net.URL;
import java.rmi.RemoteException;

import javax.xml.rpc.ServiceException;

import net.bcgi.common.jmon.monitor.BCGLogger;

import org.apache.axis.AxisFault;

import com.xius.smf.domaindata.BulkLUJobData;
import com.xius.smf.domaindata.BulkSimSwapJobData;
import com.xius.smf.domaindata.BulkStateChangeJobData;
import com.xius.smf.exceptions.SMFAgentException;
import com.xius.smf.utils.InitiateAll;
import com.xius.smf.utils.SMFAgentConstants;
import com.xius.smf.utils.Utilities;
import com.xius.xbus.messages.common.SecurityId;
import com.xius.xbus.messages.common.ServiceContext;
import com.xius.xbus.messages.common.UserType;
import com.xius.xbus.messages.provisioning.device.DeviceType;
import com.xius.xbus.messages.provisioning.device.FirstLUActivationRequest;
import com.xius.xbus.messages.provisioning.device.FirstLUActivationResponse;
import com.xius.xbus.messages.provisioning.device.InitiateChngSimSwapRequest;
import com.xius.xbus.messages.provisioning.device.InitiateChngSimSwapResponse;
import com.xius.xbus.messages.provisioning.device.SubscriberStateChangeRequest;
import com.xius.xbus.messages.provisioning.device.SubscriberStateChangeResponse;
import com.xius.xbus.services.provisioning.device.DeviceServiceLocator;
import com.xius.xbus.services.provisioning.device.DeviceServicePortType;

public class XBusDeviceAppClient {

	private BCGLogger logger = BCGLogger
			.getBCGLogger(this.getClass().getName());
	DeviceServicePortType portType = null;

	public XBusDeviceAppClient() throws MalformedURLException,
			ServiceException, InstantiationException {
		String xBusURL = InitiateAll.getSMFProps().getProperty(
				"xbus.url.cxf.DeviceService");
		DeviceServiceLocator locator = new DeviceServiceLocator();
		portType = locator.getDeviceServicePort(new URL(xBusURL.trim()));

		if (null == portType) {
			throw new InstantiationException(
					"Instance of DeviceServicePortType is null");
		}

	}

	public FirstLUActivationResponse doxBusFirstLU(String IMSI,
			BulkLUJobData data) {

		FirstLUActivationRequest request = new FirstLUActivationRequest();
		FirstLUActivationResponse response = null;
		if (logger.isDebugEnabled())
			logger.debug("IMSI-----" + IMSI);

		ServiceContext serviceContext = new ServiceContext();
		SecurityId securityId = new SecurityId();
		securityId.setUserAccountName("SMF-CORP");
		securityId.setUserAccountPassword("SMF-CORP");
		if (data.getPi_network_id() != null)
			serviceContext.setCarrierId(data.getPi_network_id().toString());
		else {
			if (logger.isDebugEnabled())
				logger.debug("CarrierId is Null");
		}

		request.setUserType(UserType.CORPUSER);
		request.setMessageID("1");
		if (data.getPi_nir_code() == null) {
			securityId.setUserAccountName("IVR");
			securityId.setUserAccountPassword("IVR");

			request.setMessageID(data.getPi_office_code());
			request.setUserType(UserType.IVR);

			request.setSim(data.getPi_iccid());

		}
		request.setSecurityId(securityId);
		request.setServiceContext(serviceContext);
		if (null != data.getChannel())
			request.setChannel(data.getChannel());

		request.setImsi(IMSI);

		request.setZipCode("123456");

		try {
			response = portType.firstLUActivation(request);
		} catch (AxisFault e) {
			logger.error(Utilities.getStackTrace(e));
		} catch (RemoteException e) {
			logger.error(Utilities.getStackTrace(e));
		}
		return response;
	}

	public InitiateChngSimSwapResponse doxBusInitiateChngSimSwap( String sim,
			BulkSimSwapJobData data) throws SMFAgentException {
		
		logger.info("XBusDeviceAppClient-doxBusInitiateChngSimSwap called");

		InitiateChngSimSwapRequest request = new InitiateChngSimSwapRequest();
		InitiateChngSimSwapResponse response = null;
		if (logger.isDebugEnabled())
			logger.debug("SIM-----" + sim);
		ServiceContext serviceContext = new ServiceContext();
		SecurityId securityId = new SecurityId();

		request.setDeviceType(DeviceType.SIM);
		securityId.setUserAccountName(data.getPi_login_id());
		securityId.setUserAccountPassword("SMF-JOB");
		if (data.getPi_network_id() != null)
			serviceContext.setCarrierId(data.getPi_network_id().toString());
		else {
			if (logger.isDebugEnabled())
				logger.debug("CarrierId is Null");
		}

		request.setUserType(UserType.CCUSER);
		request.setMessageID("1");
		request.setSecurityId(securityId);
		request.setServiceContext(serviceContext);
		if (null != data.getTrans_id()) {
			request.setExTransId(data.getTrans_id());
		}
		if (null != sim) {
			request.setOldsim(sim);
		}
		if (null != data.getPi_new_sim()) {
			request.setNewsim(data.getPi_new_sim());
		}
		if(null != data.getPi_old_msisdn()){
		request.setOldMSISDN(data.getPi_old_msisdn());
		}
		try {
			response = portType.initiateChngSimSwap(request);
		} catch (AxisFault e) {
			logger.error("AxisFault "+Utilities.getStackTrace(e));
			throw new SMFAgentException(SMFAgentConstants.DEFAULT_ERROR_CODE,e.getLocalizedMessage());
		} catch (RemoteException e) {
			logger.error("RemoteException "+Utilities.getStackTrace(e));
			throw new SMFAgentException(SMFAgentConstants.DEFAULT_ERROR_CODE,e.getLocalizedMessage());
		}catch (Exception e) {
			logger.error("Exception "+Utilities.getStackTrace(e));
			throw new SMFAgentException(SMFAgentConstants.DEFAULT_ERROR_CODE,e.getLocalizedMessage());
		}
		logger.info("XBusDeviceAppClient-doxBusInitiateChngSimSwap call Ended");
		return response;
	}
	
	public SubscriberStateChangeResponse doxBusSubscriberStateChange(
			BulkStateChangeJobData data) throws SMFAgentException {
		
		logger.info("XBusDeviceAppClient-doxBusSubscriberStateChange called");

		SubscriberStateChangeRequest request = new SubscriberStateChangeRequest();
		SubscriberStateChangeResponse response = null;
		if (logger.isDebugEnabled())
			logger.debug("MSISDN-----" + data.getMSISDN());
		ServiceContext serviceContext = new ServiceContext();
		SecurityId securityId = new SecurityId();

		securityId.setUserAccountName(data.getPi_login_id());
		securityId.setUserAccountPassword("SMF-JOB");
		if (data.getPi_network_id() != null)
			serviceContext.setCarrierId(data.getPi_network_id().toString());
		else {
			if (logger.isDebugEnabled())
				logger.debug("CarrierId is Null");
		}
		request.setVersion("1.0");
		request.setUserType(UserType.CCUSER);
		request.setMessageID("1");
		request.setSecurityId(securityId);
		request.setServiceContext(serviceContext);
		
		if (null != data.getPi_network_id()) {
			request.setTransactionId(data.getTransactionId());;
		}
		if(null!=data.getChannelId()){
			request.setChannelId(data.getChannelId());
		}
		if(null!= data.getMSISDN()){
			request.setMSISDN(data.getMSISDN());
		}
		if(null!=data.getNewStatus()){
			request.setNewStatus(data.getNewStatus());
		}
		if(null!=data.getReason()){
			request.setReason(data.getReason());
		}
		if(null!=data.getTransactionId()){
			request.setTransactionId(data.getTransactionId());
			
		}
			
		try {
			response = portType.subscriberStateChange(request);
		} catch (AxisFault e) {
			logger.error("AxisFault "+Utilities.getStackTrace(e));
			throw new SMFAgentException(SMFAgentConstants.DEFAULT_ERROR_CODE,e.getLocalizedMessage());
		} catch (RemoteException e) {
			logger.error("RemoteException "+Utilities.getStackTrace(e));
			throw new SMFAgentException(SMFAgentConstants.DEFAULT_ERROR_CODE,e.getLocalizedMessage());
		}catch (Exception e) {
			logger.error("Exception "+Utilities.getStackTrace(e));
			throw new SMFAgentException(SMFAgentConstants.DEFAULT_ERROR_CODE,e.getLocalizedMessage());
		}
		logger.info("XBusDeviceAppClient-doxBusSubscriberStateChange call Ended");
		return response;
	}

}
