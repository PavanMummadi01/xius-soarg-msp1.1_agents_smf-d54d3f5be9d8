package com.xius.smf.domaindata;


public class ViewSimSwapDetailsRefCursorData {
	
	private String simswap_details;

	public String getSimswap_details() {
		return simswap_details;
	}

	public void setSimswap_details(String simswap_details) {
		this.simswap_details = simswap_details;
	}
	
}
