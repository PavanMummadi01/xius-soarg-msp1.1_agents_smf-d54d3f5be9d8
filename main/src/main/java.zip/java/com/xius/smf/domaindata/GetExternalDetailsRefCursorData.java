package com.xius.smf.domaindata;

public class GetExternalDetailsRefCursorData {
	
	private String id_type;
	private String id_value;
	private String sim_no;
	private Long msisdn_no;
	private String external_id;
	private String invoker_id;
	private String tariffplan_id;
	private String process_flag;
	private String inserted_date;
	private String executed_date;
	private String force_action_flag;
	private String extarnal_trans_id;
	
	public String getId_type() {
		return id_type;
	}
	public void setId_type(String id_type) {
		this.id_type = id_type;
	}
	public String getId_value() {
		return id_value;
	}
	public void setId_value(String id_value) {
		this.id_value = id_value;
	}
	public String getSim_no() {
		return sim_no;
	}
	public void setSim_no(String sim_no) {
		this.sim_no = sim_no;
	}
	public Long getMsisdn_no() {
		return msisdn_no;
	}
	public void setMsisdn_no(Long msisdn_no) {
		this.msisdn_no = msisdn_no;
	}
	public String getExternal_id() {
		return external_id;
	}
	public void setExternal_id(String external_id) {
		this.external_id = external_id;
	}
	public String getInvoker_id() {
		return invoker_id;
	}
	public void setInvoker_id(String invoker_id) {
		this.invoker_id = invoker_id;
	}
	public String getTariffplan_id() {
		return tariffplan_id;
	}
	public void setTariffplan_id(String tariffplan_id) {
		this.tariffplan_id = tariffplan_id;
	}
	public String getProcess_flag() {
		return process_flag;
	}
	public void setProcess_flag(String process_flag) {
		this.process_flag = process_flag;
	}
	public String getInserted_date() {
		return inserted_date;
	}
	public void setInserted_date(String inserted_date) {
		this.inserted_date = inserted_date;
	}
	public String getExecuted_date() {
		return executed_date;
	}
	public void setExecuted_date(String executed_date) {
		this.executed_date = executed_date;
	}
	public String getForce_action_flag() {
		return force_action_flag;
	}
	public void setForce_action_flag(String force_action_flag) {
		this.force_action_flag = force_action_flag;
	}
	public String getExtarnal_trans_id() {
		return extarnal_trans_id;
	}
	public void setExtarnal_trans_id(String extarnal_trans_id) {
		this.extarnal_trans_id = extarnal_trans_id;
	}
	
}

