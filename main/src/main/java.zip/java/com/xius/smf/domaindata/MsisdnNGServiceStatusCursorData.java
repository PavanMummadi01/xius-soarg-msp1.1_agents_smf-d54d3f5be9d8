package com.xius.smf.domaindata;

public class MsisdnNGServiceStatusCursorData {
	private String fourGprovisioned;
	private String fiveGprovisioned;
	private String reason;
	public String getFourGprovisioned() {
		return fourGprovisioned;
	}
	public void setFourGprovisioned(String fourGprovisioned) {
		this.fourGprovisioned = fourGprovisioned;
	}
	public String getFiveGprovisioned() {
		return fiveGprovisioned;
	}
	public void setFiveGprovisioned(String fiveGprovisioned) {
		this.fiveGprovisioned = fiveGprovisioned;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}

}
