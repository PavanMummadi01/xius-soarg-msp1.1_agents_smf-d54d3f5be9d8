/**
 * Copyright   2006 New Wireless Services, Inc.
 * All rights reserved. These computer programs, listings, and
 * specifications are the property of New Wireless Services,
 * Inc. and may not be copied, stored, used or transmitted, in
 * whole or in part, in any for or by any means, without the
 * prior written permission of New Wireless Services, Inc.
 *
 */



package com.xius.smf.startup;

//~--- non-JDK imports --------------------------------------------------------

import javax.servlet.http.HttpServlet;

import net.bcgi.common.jmon.monitor.BCGLevel;
import net.bcgi.common.jmon.monitor.BCGLogger;

import com.xius.smf.utils.InitiateAll;
import com.xius.smf.utils.Utilities;

public class StartUpServlet extends HttpServlet {

    /**
     * Logger for this class
     */
    static BCGLogger logger = BCGLogger.getBCGLogger("StartUpServlet");

    public void init() {
    	
        if (logger.isInfoEnabled()) {
            logger.log(BCGLevel.INFO, "init Invoked .............................................");
        }
        try {

            // getting the startup data
        	 InitiateAll iniateAll = new InitiateAll();
        	 iniateAll.loadAll();
        } catch (Exception _exp) {
            logger.log(BCGLevel.ERROR, "StartUp servlet failed..." + Utilities.getStackTrace(_exp));
        }
    }
}
