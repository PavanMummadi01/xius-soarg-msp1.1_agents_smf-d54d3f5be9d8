package com.xius.smf.job;

import net.bcgi.common.jmon.monitor.BCGLevel;
import net.bcgi.common.jmon.monitor.BCGLogger;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.StatefulJob;

import com.xius.smf.job.task.SubscriberBulkUploadTask;
import com.xius.smf.job.task.UploadSIMSTask;
import com.xius.smf.utils.Utilities;

public class UploadSIMSJob implements Job , StatefulJob {

	final BCGLogger logger = BCGLogger.getBCGLogger("UploadSIMSJob");
	public void execute(JobExecutionContext executionContext) throws JobExecutionException {
		
		long start = System.currentTimeMillis();
		logger.log(BCGLevel.INFO,"=========== UploadSIMSJob Started ===========");
		try {
			
			UploadSIMSTask task = new UploadSIMSTask();
			task.doJob();
		} catch (Exception e) {

			logger.log(BCGLevel.ERROR,"Exception in UploadSIMSJob execute() :"+Utilities.getStackTrace(e));
		} 
		
		logger.log(BCGLevel.INFO,"=========== UploadSIMSJob Ended ===========");
		logger.log(BCGLevel.INFO,"### ### ### Total Time taken to execute UploadSIMSJob in (milli secons): " + (System.currentTimeMillis() - start)  );
	}
}
