package com.xius.smf.domaindata;


public class ViewSIMDetailsRefCursorData {
	
	private String sim_details;

	public String getSim_details() {
		return sim_details;
	}

	public void setSim_details(String sim_details) {
		this.sim_details = sim_details;
	}
}
