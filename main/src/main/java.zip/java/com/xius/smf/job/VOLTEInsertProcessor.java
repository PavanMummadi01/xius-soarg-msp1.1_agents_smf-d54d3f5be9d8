package com.xius.smf.job;

import net.bcgi.common.jmon.monitor.BCGLevel;
import net.bcgi.common.jmon.monitor.BCGLogger;
import net.bcgi.util.db.SPFactory;

import com.xius.smf.domaindata.TTPCRFUpdateDATA;
import com.xius.smf.domaindata.VolteInsertData;
import com.xius.smf.utils.ServiceUtils;
import com.xius.smf.utils.Utilities;

public class VOLTEInsertProcessor  {
	
	private static final BCGLogger logger = BCGLogger
			.getBCGLogger(VOLTEInsertProcessor.class.getSimpleName());

	public void statusInsert(VolteInsertData insertData)throws Exception {
		
		 
		SPFactory factory = ServiceUtils.executeSPWithOutCommit("pro_lte_srvc_req_insrt",insertData, insertData);

		if (logger.isInfoEnabled()) {
			logger.log(BCGLevel.INFO, insertData.toString());
		}

		Utilities.commitOrRollback(factory, insertData.getPo_error_code());

		if (logger.isInfoEnabled()) {
			logger.log(BCGLevel.INFO,"Error Code from pro_lte_srvc_req_insrt  ==>"+ insertData.getPo_error_code());
			logger.log(BCGLevel.INFO,"Error Msg from pro_lte_srvc_req_insrt  ==>"+ insertData.getPo_error_desc());
			logger.log(BCGLevel.INFO,"internal transaction id from pro_lte_srvc_req_insrt  ==>"+ insertData.getPo_intrnl_transaction_id());
		}	
		
	}

}