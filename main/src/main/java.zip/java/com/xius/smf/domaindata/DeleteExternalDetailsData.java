package com.xius.smf.domaindata;

public class DeleteExternalDetailsData extends DomainDataBase{


    
    private String pi_id_value;
	 private Long pi_msisdn;
	 private String pi_sim_no;
	 private String pi_external_id;
	 private String pi_invoker_id;
	 private String pi_channel;
	 private String po_trans_status;
	 private String pio_trans_ref_num;
	 private String po_trans_id;
	 
	public String getPi_id_value() {
		return pi_id_value;
	}
	public void setPi_id_value(String pi_id_value) {
		this.pi_id_value = pi_id_value;
	}
	public Long getPi_msisdn() {
		return pi_msisdn;
	}
	public void setPi_msisdn(Long pi_msisdn) {
		this.pi_msisdn = pi_msisdn;
	}
	public String getPi_sim_no() {
		return pi_sim_no;
	}
	public void setPi_sim_no(String pi_sim_no) {
		this.pi_sim_no = pi_sim_no;
	}
	public String getPi_external_id() {
		return pi_external_id;
	}
	public void setPi_external_id(String pi_external_id) {
		this.pi_external_id = pi_external_id;
	}
	public String getPi_invoker_id() {
		return pi_invoker_id;
	}
	public void setPi_invoker_id(String pi_invoker_id) {
		this.pi_invoker_id = pi_invoker_id;
	}
	public String getPi_channel() {
		return pi_channel;
	}
	public void setPi_channel(String pi_channel) {
		this.pi_channel = pi_channel;
	}
	public String getPo_trans_status() {
		return po_trans_status;
	}
	public void setPo_trans_status(String po_trans_status) {
		this.po_trans_status = po_trans_status;
	}
	public String getPio_trans_ref_num() {
		return pio_trans_ref_num;
	}
	public void setPio_trans_ref_num(String pio_trans_ref_num) {
		this.pio_trans_ref_num = pio_trans_ref_num;
	}
	public String getPo_trans_id() {
		return po_trans_id;
	}
	public void setPo_trans_id(String po_trans_id) {
		this.po_trans_id = po_trans_id;
	}
	
	 
}
