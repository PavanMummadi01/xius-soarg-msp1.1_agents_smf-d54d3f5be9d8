package com.xius.smf.domaindata;


public class ViewMSISDNDetailsRefCursorData {
	
	private String msisdn_details;
	
	public String getMsisdn_details() {
		return msisdn_details;
	}
	public void setMsisdn_details(String msisdn_details) {
		this.msisdn_details = msisdn_details;
	}
	
	
	
}
