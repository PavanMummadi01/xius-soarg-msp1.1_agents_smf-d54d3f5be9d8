package com.xius.smf.domaindata;

public class ViewStateChanegReportsCursorData {
	
	private String state_change_details;

	public String getState_change_details() {
		return state_change_details;
	}

	public void setState_change_details(String state_change_details) {
		this.state_change_details = state_change_details;
	}

	
	
	
}
