package com.xius.smf.config;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.StringWriter;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamReader;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.WebServiceMessage;
import org.springframework.ws.context.MessageContext;
import org.springframework.ws.server.EndpointInterceptor;
import org.springframework.ws.soap.SoapHeader;
import org.springframework.ws.soap.SoapMessage;

import com.xius.agent.smf.common.header.headerdetails.MessageHeader;
import com.xius.agent.smf.common.header.headerdetails.ObjectFactory;
import com.xius.agent.smf.common.header.headerdetails.TrackingMessageHeaderType;

import net.bcgi.common.jmon.monitor.BCGLogger;



public class HeaderInterceptorService implements EndpointInterceptor {

	private static final BCGLogger LOGGER = BCGLogger.getBCGLogger(HeaderInterceptorService.class.getSimpleName());

	private CurrentHeader currentHeader;

	@Autowired
	HeaderInterceptorService(CurrentHeader currentHeader) {
		this.currentHeader = currentHeader;
	}

	HeaderInterceptorService() {

	}

	public void afterCompletion(MessageContext arg0, Object arg1, Exception arg2) throws Exception {
		
	}


	public boolean handleFault(MessageContext arg0, Object arg1) throws Exception {
		LOGGER.info("------------ handleFAULT ------------ ");
		;
		WebServiceMessage webServiceMessageRequest = arg0.getResponse();
		SoapMessage soapMessage = (SoapMessage) webServiceMessageRequest;
		SoapHeader soapHeader = soapMessage.getSoapHeader();
		ObjectFactory factory = new ObjectFactory();
		MessageHeader msgheader = factory.createMessageHeader();
		msgheader.setTrackingMessageHeader(this.currentHeader.getCurrentUser());
		JAXBContext jc = JAXBContext.newInstance(MessageHeader.class);
		Marshaller marshaller = jc.createMarshaller();
		marshaller.marshal(msgheader, soapHeader.getResult());

		return true;
	}

	
	public boolean handleRequest(MessageContext messageContext_, Object arg1) throws Exception {
		LOGGER.info("------------ handleRequest ------------ ");

		WebServiceMessage webServiceMessageRequest = messageContext_.getRequest();
		SoapMessage soapMessage = (SoapMessage) webServiceMessageRequest;
		SoapHeader soapHeader = soapMessage.getSoapHeader();

		Source bodySource = soapHeader.getSource();

		StringWriter writer = new StringWriter();
		TransformerFactory transformerFactory = TransformerFactory.newInstance();
		Transformer transformer = transformerFactory.newTransformer();
		transformer.transform(bodySource, new StreamResult(writer));
		String str = writer.toString();

		XMLInputFactory xif = XMLInputFactory.newInstance();

		InputStream stream = new ByteArrayInputStream(str.getBytes());
		StreamSource xml = new StreamSource(stream);
		XMLStreamReader xsr = xif.createXMLStreamReader(xml);
		xsr.nextTag();
		while (!xsr.getLocalName().equals("trackingMessageHeader")) {
			xsr.nextTag();
		}

		JAXBContext jc = JAXBContext.newInstance(TrackingMessageHeaderType.class);
		Unmarshaller unmarshaller = jc.createUnmarshaller();
		JAXBElement<TrackingMessageHeaderType> jb = unmarshaller.unmarshal(xsr, TrackingMessageHeaderType.class);
		xsr.close();

		TrackingMessageHeaderType customer = jb.getValue();
		this.currentHeader.setCurrentUser(customer);

		return true;
	}


	public boolean handleResponse(MessageContext arg0, Object arg1) throws Exception {
		LOGGER.info("------------ handleResponse ------------ ");

		WebServiceMessage webServiceMessageRequest = arg0.getResponse();
		SoapMessage soapMessage = (SoapMessage) webServiceMessageRequest;
		SoapHeader soapHeader = soapMessage.getSoapHeader();
		ObjectFactory factory = new ObjectFactory();
		MessageHeader msgheader = factory.createMessageHeader();
		msgheader.setTrackingMessageHeader(this.currentHeader.getCurrentUser());
		JAXBContext jc = JAXBContext.newInstance(MessageHeader.class);
		Marshaller marshaller = jc.createMarshaller();
		marshaller.marshal(msgheader, soapHeader.getResult());

		return true;
	}

}
