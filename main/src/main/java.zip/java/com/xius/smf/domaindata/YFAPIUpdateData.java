package com.xius.smf.domaindata;

public class YFAPIUpdateData extends DomainDataBase{
	
	private String pi_activityId;
	private String pi_ref_tarnsation_id;
	private String pi_remarks;
	private String pi_status;
	/**
	 * @return the pi_activityId
	 */
	public String getPi_activityId() {
		return pi_activityId;
	}
	/**
	 * @param pi_activityId the pi_activityId to set
	 */
	public void setPi_activityId(String pi_activityId) {
		this.pi_activityId = pi_activityId;
	}
	/**
	 * @return the pi_ref_tarnsation_id
	 */
	public String getPi_ref_tarnsation_id() {
		return pi_ref_tarnsation_id;
	}
	/**
	 * @param pi_ref_tarnsation_id the pi_ref_tarnsation_id to set
	 */
	public void setPi_ref_tarnsation_id(String pi_ref_tarnsation_id) {
		this.pi_ref_tarnsation_id = pi_ref_tarnsation_id;
	}
	/**
	 * @return the pi_remarks
	 */
	public String getPi_remarks() {
		return pi_remarks;
	}
	/**
	 * @param pi_remarks the pi_remarks to set
	 */
	public void setPi_remarks(String pi_remarks) {
		this.pi_remarks = pi_remarks;
	}
	/**
	 * @return the pi_status
	 */
	public String getPi_status() {
		return pi_status;
	}
	/**
	 * @param pi_status the pi_status to set
	 */
	public void setPi_status(String pi_status) {
		this.pi_status = pi_status;
	}
	
	
	
	 
  }
