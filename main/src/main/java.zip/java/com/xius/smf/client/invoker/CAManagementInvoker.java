/******************************************************************
 * Company XIUS (Megasoft Pvt Ltd Hyderabad,INDIA)
 * � Copyright 2006 MEGASOFT. 
 *
 * Package      : com.xius.mspgw.client.invoker;
 * Name of File : ProductPurchageInvoker.java
 * Date /Year   : Dec 09, 2016
 * Author       : Sambasiva Rao Aakula
 * Discription  : 
 *
 * Method names : 
 * 
 * Modifications
 * Method Name  |  Date   |  Author  | Explanation
 * -------------------------------------------------------------              
 *              |         |          |
 *              |         |          | 
 *             
 ********************************************************************/
package com.xius.smf.client.invoker;

import java.net.MalformedURLException;
import java.net.URL;
import java.rmi.RemoteException;

import net.bcgi.common.jmon.monitor.BCGLevel;
import net.bcgi.common.jmon.monitor.BCGLogger;

import org.apache.axis.AxisFault;
import org.apache.axis.message.SOAPHeaderElement;

import com.xius.billing.CAManagement_wsdl.CAManagementServicesBindingStub;
import com.xius.billing.CAManagement_wsdl.CAManagementServicesLocator;
import com.xius.billing.CAManagement_xsd.CAAccountExistCountRequest;
import com.xius.billing.CAManagement_xsd.CAAccountExistCountResponse;

import com.xius.billing.common.error.ErrorDetails_xsd.ErrorDetailsType;
import com.xius.smf.exceptions.SMFAgentException;
import com.xius.smf.utils.HeaderDetails;
import com.xius.smf.utils.InitiateAll;
import com.xius.smf.utils.SMFAgentConstants;
import com.xius.smf.utils.Utilities;

public class CAManagementInvoker {
	private static final BCGLogger logger = BCGLogger
			.getBCGLogger(CAManagementInvoker.class.getSimpleName());

	public CAAccountExistCountResponse cAAccountExistCount(HeaderDetails headerDetails,
			CAAccountExistCountRequest Request) throws SMFAgentException {
		long startTime = System.currentTimeMillis();
		long endTime = 0;
		String url = InitiateAll.getSMFProps().getProperty("iba.CAManagement");
		if (logger.isInfoEnabled()) {
			logger.info("the url for request" + url);
		}
		CAAccountExistCountResponse response = null;
		CAManagementServicesBindingStub bindingStub = null;
		try {
			bindingStub = new CAManagementServicesBindingStub(new URL(url),new CAManagementServicesLocator());
			SOAPHeaderElement header = Utilities.getSoapHeader(headerDetails);
			bindingStub.setHeader(header);

			bindingStub.setTimeout(Integer.parseInt(InitiateAll.getSMFProps().getProperty("iba.timeout")));

			response = bindingStub.cAAccountExistCount(Request);

			if (response != null) {
				if (logger.isInfoEnabled()) {
					logger.log(BCGLevel.INFO,
							">>>Response from  CAManagementInvoker---> CAAccountExistCount api getConfigureCaParentCount : "
									+ response.getConfigureCaParentCount());
					logger.log(BCGLevel.INFO,
							">>>Response from  CAManagementInvoker---> CAAccountExistCount api getUsedCaParentCount : "
									+ response.getUsedCaParentCount());
					
					endTime = System.currentTimeMillis();
					logger.log(BCGLevel.INFO,
							" CAManagementInvoker--->Recharge Success:"
									+ (int) (endTime - startTime) + "ms");
				}
			} else {
				logger.log(BCGLevel.ERROR,
						"No response from IBA for CAManagementInvoker---> CAAccountExistCount api..");
				endTime = System.currentTimeMillis();
				logger.log(BCGLevel.INFO,
						" CAManagementInvoker--->CAManagementInvoker Failure:"
								+ (int) (endTime - startTime) + "ms");
				throw new SMFAgentException(SMFAgentConstants.INTERNAL_ERROR_CODE_STR, null);
			}

		} catch (ErrorDetailsType e) {
			logger.log(BCGLevel.ERROR,
					" CAManagementInvoker--->CAAccountExistCount - ErrorDetailsType ErroCode:"
							+ e.getErrorCode());
			logger.log(BCGLevel.ERROR,
					" CAManagementInvoker--->CAAccountExistCount - ErrorDetailsType ErrorMessage:"
							+ e.getErrorMessage());
			endTime = System.currentTimeMillis();
			if (logger.isInfoEnabled()) {
				logger.log(BCGLevel.INFO,
						" CAManagementInvoker--->CAAccountExistCount Failure:"
								+ (int) (endTime - startTime) + "ms");
			}
			throw new SMFAgentException(e.getErrorCode(), e.getErrorMessage());
		} catch (AxisFault e) {
			logger.log(BCGLevel.ERROR,
					" CAManagementInvoker--->CAAccountExistCount- AxisFault :"
							+ Utilities.getStackTrace(e));
			endTime = System.currentTimeMillis();
			if (logger.isInfoEnabled()) {
				logger.log(BCGLevel.INFO,
						" CAManagementInvoker--->CAAccountExistCount aFilure:"
								+ (int) (endTime - startTime) + "ms");
			}
			throw new SMFAgentException(SMFAgentConstants.INTERNAL_ERROR_CODE_STR,null);
		} catch (RemoteException e) {
			logger.log(BCGLevel.ERROR,
					"CAManagementInvoker--->CAAccountExistCount - RemoteException:"
							+ Utilities.getStackTrace(e));
			endTime = System.currentTimeMillis();
			if (logger.isInfoEnabled()) {
				logger.log(BCGLevel.INFO,
						" CAManagementInvoker--->CAAccountExistCount Failure:"
								+ (int) (endTime - startTime) + "ms");
			}
			throw new SMFAgentException(SMFAgentConstants.INTERNAL_ERROR_CODE_STR,null);
		} catch (MalformedURLException e) {
			logger.log(BCGLevel.ERROR,
					" CAManagementInvoker--->CAAccountExistCount - MalformedURLException :"
							+Utilities.getStackTrace(e));
			endTime = System.currentTimeMillis();
			if (logger.isInfoEnabled()) {
				logger.log(BCGLevel.INFO,
						" CAManagementInvoker--->CAAccountExistCount Failure:"
								+ (int) (endTime - startTime) + "ms");
			}
			throw new SMFAgentException(SMFAgentConstants.INTERNAL_ERROR_CODE_STR,null);
		}
		return response;
	}
}
