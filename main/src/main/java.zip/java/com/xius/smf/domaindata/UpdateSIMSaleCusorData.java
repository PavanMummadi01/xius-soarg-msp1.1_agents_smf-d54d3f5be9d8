package com.xius.smf.domaindata;

public class UpdateSIMSaleCusorData {

	private Long serviceflag;
	private String basic_service_id;
	private String derived_service_id;
	private String atp_id;
	private String activation_fee;
	private String charge_id;
	private String publicity_id;
	private String pi_ATPUniqueid;
	
	
	public Long getServiceflag() {
		return serviceflag;
	}
	public void setServiceflag(Long serviceflag) {
		this.serviceflag = serviceflag;
	}
	public String getBasic_service_id() {
		return basic_service_id;
	}
	public void setBasic_service_id(String basic_service_id) {
		this.basic_service_id = basic_service_id;
	}
	public String getDerived_service_id() {
		return derived_service_id;
	}
	public void setDerived_service_id(String derived_service_id) {
		this.derived_service_id = derived_service_id;
	}
	public String getAtp_id() {
		return atp_id;
	}
	public void setAtp_id(String atp_id) {
		this.atp_id = atp_id;
	}
	public String getActivation_fee() {
		return activation_fee;
	}
	public void setActivation_fee(String activation_fee) {
		this.activation_fee = activation_fee;
	}
	public String getCharge_id() {
		return charge_id;
	}
	public void setCharge_id(String charge_id) {
		this.charge_id = charge_id;
	}
	public String getPublicity_id() {
		return publicity_id;
	}
	public void setPublicity_id(String publicity_id) {
		this.publicity_id = publicity_id;
	}
	public String getPi_ATPUniqueid() {
		return pi_ATPUniqueid;
	}
	public void setPi_ATPUniqueid(String pi_ATPUniqueid) {
		this.pi_ATPUniqueid = pi_ATPUniqueid;
	}

	
	
}
