package com.xius.smf.domaindata;

public class IMEIEnquiryHistData   {

	private String taskPerfomed;
	private String taskAssignedOn;
	private String taskPerfomedBy;
	private String Country;
	public String getTaskPerfomed() {
		return taskPerfomed;
	}
	public void setTaskPerfomed(String taskPerfomed) {
		this.taskPerfomed = taskPerfomed;
	}
	public String getTaskAssignedOn() {
		return taskAssignedOn;
	}
	public void setTaskAssignedOn(String taskAssignedOn) {
		this.taskAssignedOn = taskAssignedOn;
	}
	public String getTaskPerfomedBy() {
		return taskPerfomedBy;
	}
	public void setTaskPerfomedBy(String taskPerfomedBy) {
		this.taskPerfomedBy = taskPerfomedBy;
	}
	public String getCountry() {
		return Country;
	}
	public void setCountry(String country) {
		Country = country;
	}

}

