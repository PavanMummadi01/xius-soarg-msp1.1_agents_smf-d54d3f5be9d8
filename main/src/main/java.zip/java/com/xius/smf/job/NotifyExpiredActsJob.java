/**
 * Copyright   2012 XIUS.
 * All rights reserved. These computer programs, listings, and
 * specifications are the property of XIUS. 
 * And may not be copied, stored, used or transmitted, in
 * whole or in part, in any for or by any means, without the
 * prior written permission of XIUS.
 *
 */
/**
 * ${todo}
 * @author srikanthm $Author: shashidhar.p $
 * @version $Id: //depot/xb/MSP1.0/MSP-AWS/agents/smf/main/src/main/java/com/xius/smf/job/NotifyExpiredActsJob.java#1 $ 
 * $DateTime: 2023/09/20 17:37:16 $Change:  $
 */

package com.xius.smf.job;

import java.math.BigDecimal;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import net.bcgi.common.jmon.monitor.BCGLevel;
import net.bcgi.common.jmon.monitor.BCGLogger;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import com.xius.smf.domaindata.GetExpiredActsData;
import com.xius.smf.exceptions.SMFAgentException;
import com.xius.smf.scoket.DCCSClient;
import com.xius.smf.utils.InitiateAll;
import com.xius.smf.utils.SMFAgentConstants;
import com.xius.smf.utils.ServiceUtils;
import com.xius.smf.utils.Utilities;


public class NotifyExpiredActsJob implements Job{

	static BCGLogger logger = BCGLogger.getBCGLogger(NotifyExpiredActsJob.class.getSimpleName());
	final ArrayBlockingQueue<Runnable> queue = new ArrayBlockingQueue<Runnable>(100000);
	private ThreadPoolExecutor executor;

	public void execute(JobExecutionContext arg0) throws JobExecutionException {

		BigDecimal[] expiredMsisdns = callDBforExpiredActs();

		if( null != expiredMsisdns && expiredMsisdns.length > 0 ) {

			logger.log(BCGLevel.INFO, "No. of msisdns to be expired found : " + expiredMsisdns.length );

			executor = new ThreadPoolExecutor(10, 10, 100000, TimeUnit.SECONDS, queue);
			exeUsingThreadPoolExecutor( expiredMsisdns );
		} else {

			logger.log(BCGLevel.INFO, "*** *** *** Found No msisdns to be expired to notify DCCS");
		}
	}

	private void exeUsingThreadPoolExecutor(BigDecimal[] expiredMsisdns){

		try {

			long startTimeTotal = System.currentTimeMillis();
			executor = new ThreadPoolExecutor(10, 10, 100000, TimeUnit.SECONDS, queue);
			DCCSClient worker = null;

			for( int i = 0; i < expiredMsisdns.length; i++ ) {

				if( null != expiredMsisdns[i] ) {

					worker = new DCCSClient( expiredMsisdns[i].toString() );
					worker.setLocalTcpIpConfig( InitiateAll.tcpIpConfig );
					executor.execute(worker);
				}
			}

			// This will make the executor accept no new threads
			// and finish all existing threads in the queue
			executor.shutdown();
			// Wait until all threads are finish
			while (!executor.isTerminated()) {

			}

			long totalTime = System.currentTimeMillis() - startTimeTotal;
			logger.log(BCGLevel.INFO, "<<<### ### ###>>>Total Time taken for sending expiredMsisdns to DCCS in (secons) : " + (totalTime/1000));
		} catch (Exception e) {

			logger.log(BCGLevel.ERROR, Utilities.getStackTrace( e ) );
		} finally {

			logger.log(BCGLevel.INFO,"*** NotifyExpiredActsJob is job compleeted... Shout Downing ThreadPool");
			executor.shutdown();

			logger.log(BCGLevel.INFO,"*** Making executor null intentionally");
			executor = null;
		}
	} 

	/**
	 * This method is used to call database procedure for getting the expired accounts 
	 * 
	 * @return
	 */
	private BigDecimal[] callDBforExpiredActs() {

		//just for safety adding this
		Long networkID = 1L;
		String networkId = InitiateAll.getSMFProps().getProperty( SMFAgentConstants.NETWORKID_PROP );
		GetExpiredActsData domainData = new GetExpiredActsData();

		if(Utilities.isNull(networkId) == false)
			networkID = new Long(networkId).longValue();

		/**
		 * Setting the input
		 */
		domainData.setPi_network_id(networkID);

		try {
			/**
			 * calling db proc using mosf
			 */
			ServiceUtils._executeStoredProcedure("get_exp_msisdns", domainData, domainData);
			
			if(logger.isInfoEnabled()) {

				logger.log(BCGLevel.INFO, "Error Code in get_exp_msisdns==>"+domainData.getPo_error_code());
			}

		} catch (SMFAgentException e) {
			logger.log(BCGLevel.ERROR, "Exception in callDBforExpiredActs \n"+Utilities.getStackTrace(e));
		}

		return domainData.getPo_expired_msisdns();
	} // end of method callDBforExpiredActs()
}

