package com.xius.smf.job;

import net.bcgi.common.jmon.monitor.BCGLevel;
import net.bcgi.common.jmon.monitor.BCGLogger;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.StatefulJob;

import com.xius.smf.job.task.SubscriberBulkUploadTask;
import com.xius.smf.job.task.UploadBulkIDReplacementTask;
import com.xius.smf.job.task.UploadSIMSTask;
import com.xius.smf.utils.Utilities;

public class UploadBulkIDReplacementJob implements Job , StatefulJob {

	final BCGLogger logger = BCGLogger.getBCGLogger("UploadBulkIDReplacementJob");
	public void execute(JobExecutionContext executionContext) throws JobExecutionException {
		
		long start = System.currentTimeMillis();
		logger.log(BCGLevel.INFO,"=========== UploadBulkIDReplacementJob Started ===========");
		
		try {
			
			UploadBulkIDReplacementTask task = new UploadBulkIDReplacementTask();
			task.doJob();
		} catch (Exception e) {

			logger.log(BCGLevel.ERROR,"Exception in UploadBulkIDReplacementJob execute() :"+Utilities.getStackTrace(e));
		} 
		
		logger.log(BCGLevel.INFO,"=========== UploadBulkIDReplacementJob Ended ===========");
		logger.log(BCGLevel.INFO,"### ### ### Total Time taken to execute UploadBulkIDReplacementJob in (milli secons): " + (System.currentTimeMillis() - start));
		
	}

}
