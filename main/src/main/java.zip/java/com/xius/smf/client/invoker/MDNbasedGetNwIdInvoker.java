package com.xius.smf.client.invoker;

import java.net.MalformedURLException;
import java.net.URL;
import java.rmi.RemoteException;

import net.bcgi.common.jmon.monitor.BCGLevel;
import net.bcgi.common.jmon.monitor.BCGLogger;

import org.apache.axis.AxisFault;
import org.apache.axis.message.SOAPHeaderElement;

import com.xius.billing.AccountManagement_wsdl.AccountManagementBindingStub;
import com.xius.billing.AccountManagement_wsdl.AccountServiceLocator;
import com.xius.billing.AccountManagement_xsd.MDNBasedGetNwIdRequest;
import com.xius.billing.AccountManagement_xsd.MDNBasedGetNwIdResponse;
import com.xius.billing.common.error.ErrorDetails_xsd.ErrorDetailsType;
import com.xius.smf.exceptions.SMFAgentException;
import com.xius.smf.utils.HeaderDetails;
import com.xius.smf.utils.InitiateAll;
import com.xius.smf.utils.SMFAgentConstants;
import com.xius.smf.utils.Utilities;

public class MDNbasedGetNwIdInvoker {
	private static final BCGLogger logger = BCGLogger
	.getBCGLogger(MDNbasedGetNwIdInvoker.class.getSimpleName());
	MDNBasedGetNwIdResponse response = null;

public MDNBasedGetNwIdResponse MDNbasedGetNwId(
	HeaderDetails headerDetails, MDNBasedGetNwIdRequest dataRequest)
	throws SMFAgentException {
long startTime = System.currentTimeMillis();
long endTime = 0;

String url = InitiateAll.getSMFProps().getProperty("iba.AccountManagement");
if (logger.isInfoEnabled()) {
	logger.info("****  The url for request  ****   :  " + url);
}

AccountManagementBindingStub bindingStub = null;
try {
	bindingStub = new AccountManagementBindingStub(new URL(url),
			new AccountServiceLocator());
	SOAPHeaderElement header = Utilities.getSoapHeader(headerDetails);
	bindingStub.setHeader(header);

	bindingStub.setTimeout(Integer.parseInt(InitiateAll.getSMFProps()
			.getProperty("iba.timeout")));
	response=new MDNBasedGetNwIdResponse();

	response = bindingStub.MDNbasedGetNwId(dataRequest);

	if (response != null) {
		if (logger.isInfoEnabled()) {

			logger.log(BCGLevel.INFO,
					">>>Response from  MDNbasedGetNwIdInvoker--->  MDNbasedGetNwId Response: "
							+ response.getNetworkId());
			logger.log(BCGLevel.INFO,
					">>>Response from  MDNbasedGetNwIdInvoker--->  MDNbasedGetNwId Response: "
							+ response.getAccountId());
			logger.log(BCGLevel.INFO,
					">>>Response from  MDNbasedGetNwIdInvoker--->  MDNbasedGetNwId Response: "
							+ response.getIdValue());
			logger.log(BCGLevel.INFO,
					">>>Response from  MDNbasedGetNwIdInvoker--->  MDNbasedGetNwId Response: "
							+ response.getIMSI());
			logger.log(BCGLevel.INFO,
					">>>Response from  MDNbasedGetNwIdInvoker--->  MDNbasedGetNwId Response: "
							+ response.getMSISDN());
			logger.log(BCGLevel.INFO,
					">>>Response from  MDNbasedGetNwIdInvoker--->  MDNbasedGetNwId Response: "
							+ response.getNetworkName());
			logger.log(BCGLevel.INFO,
					">>>Response from  MDNbasedGetNwIdInvoker--->  MDNbasedGetNwId Response: "
							+ response.getSIM());
			endTime = System.currentTimeMillis();
			logger.log(BCGLevel.INFO,
					" MDNbasedGetNwIdInvoker--->Subscriber MDNbasedGetNwId Success:"
							+ (int) (endTime - startTime) + "ms");
		}

	} else {
		logger.log(
				BCGLevel.ERROR,
				"No response from IBA for MDNbasedGetNwIdInvoker---> MDNbasedGetNwId api..");
		endTime = System.currentTimeMillis();
		logger.log(BCGLevel.INFO,
				" MDNbasedGetNwIdInvoker--->MDNbasedGetNwId Failure:"
						+ (int) (endTime - startTime) + "ms");
		throw new SMFAgentException(SMFAgentConstants.INTERNAL_ERROR_CODE_STR, null);
	}

} catch (ErrorDetailsType e) {
	logger.log(BCGLevel.ERROR,
			" MDNbasedGetNwIdInvoker--->MDNbasedGetNwId - ErrorDetailsType ErroCode:"
					+ e.getErrorCode());
	logger.log(
			BCGLevel.ERROR,
			"MDNbasedGetNwIdInvoker--->MDNbasedGetNwId - ErrorDetailsType ErrorMessage:"
					+ e.getErrorMessage());
	endTime = System.currentTimeMillis();
	if (logger.isInfoEnabled()) {
		logger.log(BCGLevel.INFO,
				" MDNbasedGetNwId--->MDNbasedGetNwId Failure:"
						+ (int) (endTime - startTime) + "ms");
	}
	throw new  SMFAgentException(e.getErrorCode(), e.getErrorMessage());
} catch (AxisFault e) {
	logger.log(BCGLevel.ERROR,
			" MDNbasedGetNwIdInvoker--->MDNbasedGetNwId - AxisFault :"
					+ Utilities.getStackTrace(e));
	endTime = System.currentTimeMillis();
	if (logger.isInfoEnabled()) {
		logger.log(BCGLevel.INFO,
				" MDNbasedGetNwIdInvoker--->MDNbasedGetNwId Filure:"
						+ (int) (endTime - startTime) + "ms");
	}
	throw new SMFAgentException(SMFAgentConstants.INTERNAL_ERROR_CODE_STR, null);
} catch (RemoteException e) {
	logger.log(BCGLevel.ERROR,
			" MDNbasedGetNwIdInvoker--->MDNbasedGetNwId - RemoteException:"
					+ Utilities.getStackTrace(e));
	endTime = System.currentTimeMillis();
	if (logger.isInfoEnabled()) {
		logger.log(BCGLevel.INFO,
				" MDNbasedGetNwIdInvoker--->MDNbasedGetNwId Failure:"
						+ (int) (endTime - startTime) + "ms");
	}
	throw new SMFAgentException(SMFAgentConstants.INTERNAL_ERROR_CODE_STR, null);
} catch (MalformedURLException e) {
	logger.log(BCGLevel.ERROR,
			" MDNbasedGetNwIdInvoker--->MDNbasedGetNwId - MalformedURLException :"
					+ Utilities.getStackTrace(e));
	endTime = System.currentTimeMillis();
	if (logger.isInfoEnabled()) {
		logger.log(BCGLevel.INFO,
				" MDNbasedGetNwIdInvoker--->MDNbasedGetNwId Failure:"
						+ (int) (endTime - startTime) + "ms");
	}
	throw new SMFAgentException(SMFAgentConstants.INTERNAL_ERROR_CODE_STR, null);
}

return response;
}

}
