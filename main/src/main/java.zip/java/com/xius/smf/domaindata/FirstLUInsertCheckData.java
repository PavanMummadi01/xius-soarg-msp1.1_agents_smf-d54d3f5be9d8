package com.xius.smf.domaindata;

public class FirstLUInsertCheckData extends DomainDataBase{
	
	private Long pi_imsi;
	private String po_trans_id;
	private String po_sim_serial_no;
	private Long po_new_msisdn;
	
	/**
	 * @return the pi_imsi
	 */
	public Long getPi_imsi() {
		return pi_imsi;
	}
	/**
	 * @param pi_imsi the pi_imsi to set
	 */
	public void setPi_imsi(Long pi_imsi) {
		this.pi_imsi = pi_imsi;
	}
	/**
	 * @return the po_trans_id
	 */
	public String getPo_trans_id() {
		return po_trans_id;
	}
	/**
	 * @param po_trans_id the po_trans_id to set
	 */
	public void setPo_trans_id(String po_trans_id) {
		this.po_trans_id = po_trans_id;
	}
	/**
	 * @return the po_sim_serial_no
	 */
	public String getPo_sim_serial_no() {
		return po_sim_serial_no;
	}
	/**
	 * @param po_sim_serial_no the po_sim_serial_no to set
	 */
	public void setPo_sim_serial_no(String po_sim_serial_no) {
		this.po_sim_serial_no = po_sim_serial_no;
	}
	/**
	 * @return the po_new_msisdn
	 */
	public Long getPo_new_msisdn() {
		return po_new_msisdn;
	}
	/**
	 * @param po_new_msisdn the po_new_msisdn to set
	 */
	public void setPo_new_msisdn(Long po_new_msisdn) {
		this.po_new_msisdn = po_new_msisdn;
	}
	
	
	 
  }
