package com.xius.smf.domaindata;



public class ManageNotificationsMsisdnsData  extends DomainDataBase{

	
	private Long[] pi_invoice_id;
	private Long[] pi_msisdn;
	private Long[] pi_reminder_type;
	
	
   /**
	 * @return the pi_invoice_id
	 */
	public Long[] getPi_invoice_id() {
		return pi_invoice_id;
	}
	/**
	 * @param pi_invoice_id the pi_invoice_id to set
	 */
	public void setPi_invoice_id(Long[] pi_invoice_id) {
		this.pi_invoice_id = pi_invoice_id;
	}
	/**
	 * @return the pi_msisdn
	 */
	public Long[] getPi_msisdn() {
		return pi_msisdn;
	}
	/**
	 * @param pi_msisdn the pi_msisdn to set
	 */
	public void setPi_msisdn(Long[] pi_msisdn) {
		this.pi_msisdn = pi_msisdn;
	}
	/**
	 * @return the pi_reminder_type
	 */
	public Long[] getPi_reminder_type() {
		return pi_reminder_type;
	}
	/**
	 * @param pi_reminder_type the pi_reminder_type to set
	 */
	public void setPi_reminder_type(Long[] pi_reminder_type) {
		this.pi_reminder_type = pi_reminder_type;
	}
   
	
	
}
