package com.xius.smf.app;


import java.io.FileInputStream;
import java.util.Properties;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

import com.xius.smf.utils.InitiateAll;
import com.xius.smf.utils.Utilities;

import net.bcgi.common.jmon.monitor.BCGLevel;
import net.bcgi.common.jmon.monitor.BCGLogger;


@SpringBootApplication(scanBasePackages = { "com.xius" })
@ComponentScan(basePackages = { "com.xius" })
public class SMFApplication {

	private static final BCGLogger LOGGER = BCGLogger.getBCGLogger(SMFApplication.class.getSimpleName());

	static {

		if (LOGGER.isInfoEnabled()) {
			LOGGER.log(BCGLevel.INFO, "init Invoked .............................................");
		}
		InitiateAll IniatAll = new InitiateAll();
		try {
			IniatAll.loadAll();
		} catch (Exception _exp) {
			LOGGER.log(BCGLevel.ERROR, "StartUp servlet failed..." + Utilities.getStackTrace(_exp));
		}
		
	}

	public static void main(String[] args) {
		SpringApplication.run(SMFApplication.class, args);

	}

	public static Properties getErrorDetails() {
		Properties errorProps = new Properties();
		try {
			errorProps.load(new FileInputStream("config/ErrorDetails.properties"));
		} catch (Exception e) {
			LOGGER.error("getErrorDetails Exception :" + e);
		}
		return errorProps; 
	}

}
