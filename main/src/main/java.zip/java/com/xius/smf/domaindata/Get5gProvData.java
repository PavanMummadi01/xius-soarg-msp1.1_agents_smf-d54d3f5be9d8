package com.xius.smf.domaindata;

public class Get5gProvData extends DomainDataBase {

	private Long pi_tariffpack_id;
	private Long pi_msisdn;
	private String po_tariffid_5gprov;
	private String po_nw_id_5gprov;
	private String po_atpid_5gprov;
	private Long pi_atp_id;

	public Long getPi_tariffpack_id() {
		return pi_tariffpack_id;
	}

	public void setPi_tariffpack_id(Long pi_tariffpack_id) {
		this.pi_tariffpack_id = pi_tariffpack_id;
	}

	public Long getPi_msisdn() {
		return pi_msisdn;
	}

	public void setPi_msisdn(Long pi_msisdn) {
		this.pi_msisdn = pi_msisdn;
	}

	public String getPo_tariffid_5gprov() {
		return po_tariffid_5gprov;
	}

	public void setPo_tariffid_5gprov(String po_tariffid_5gprov) {
		this.po_tariffid_5gprov = po_tariffid_5gprov;
	}

	public String getPo_nw_id_5gprov() {
		return po_nw_id_5gprov;
	}

	public void setPo_nw_id_5gprov(String po_nw_id_5gprov) {
		this.po_nw_id_5gprov = po_nw_id_5gprov;
	}

	public String getPo_atpid_5gprov() {
		return po_atpid_5gprov;
	}

	public void setPo_atpid_5gprov(String po_atpid_5gprov) {
		this.po_atpid_5gprov = po_atpid_5gprov;
	}

	public Long getPi_atp_id() {
		return pi_atp_id;
	}

	public void setPi_atp_id(Long pi_atp_id) {
		this.pi_atp_id = pi_atp_id;
	}
}
