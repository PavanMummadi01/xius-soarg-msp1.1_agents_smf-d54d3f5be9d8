package com.xius.smf.job;

import net.bcgi.common.jmon.monitor.BCGLevel;
import net.bcgi.common.jmon.monitor.BCGLogger;
import net.bcgi.util.db.SPFactory;

import com.xius.smf.domaindata.BulkSimSwapStatusUpdateData;
import com.xius.smf.utils.ServiceUtils;
import com.xius.smf.utils.Utilities;

public class BulkSimSwapFinalStatUpdate {
	private static final BCGLogger logger = BCGLogger.getBCGLogger(BulkSimSwapFinalStatUpdate.class.getSimpleName());

	public void statuUpdate(BulkSimSwapStatusUpdateData domainData)throws Exception {
		
		 
		SPFactory factory = ServiceUtils.executeSPWithOutCommit("pro_sim_swap_upd", domainData, domainData);

		if (logger.isInfoEnabled()) {
			logger.log(BCGLevel.INFO, domainData.toString());
		}

		Utilities.commitOrRollback(factory, domainData.getPo_error_code());

		if (logger.isInfoEnabled()) {
			logger.log(BCGLevel.INFO,"Error Code from pro_sim_swap_upd  ==>"+ domainData.getPo_error_code());
			logger.log(BCGLevel.INFO,"Error Msg from pro_sim_swap_upd  ==>"+ domainData.getPo_error_desc());
		}		
	}
	 
}
