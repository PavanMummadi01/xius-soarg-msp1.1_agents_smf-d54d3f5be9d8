package com.xius.smf.client.invoker;

import java.net.MalformedURLException;
import java.net.URL;
import java.rmi.RemoteException;

import org.apache.axis.AxisFault;
import org.apache.axis.message.SOAPHeaderElement;

import net.bcgi.common.jmon.monitor.BCGLevel;
import net.bcgi.common.jmon.monitor.BCGLogger;
import com.xius.billing.AccountManagement_wsdl.AccountManagementBindingStub;
import com.xius.billing.AccountManagement_wsdl.AccountServiceLocator;
import com.xius.billing.AccountManagement_xsd.ManagePostPaidGrpRequest;
import com.xius.billing.AccountManagement_xsd.ManagePostPaidGrpResponse;
import com.xius.smf.exceptions.SMFAgentException;
import com.xius.smf.utils.HeaderDetails;
import com.xius.smf.utils.InitiateAll;
import com.xius.smf.utils.SMFAgentConstants;
import com.xius.smf.utils.Utilities;

public class ManagePostPaidGrpInvoker {
	private static final BCGLogger logger = BCGLogger
			.getBCGLogger(ManagePostPaidGrpInvoker.class.getSimpleName());
    public ManagePostPaidGrpResponse managePostPaidGrp(ManagePostPaidGrpRequest request ,HeaderDetails headerDetails ) throws SMFAgentException{
    	long startTime = System.currentTimeMillis();
		long endTime = 0;
		String url = InitiateAll.getSMFProps().getProperty("postpaid.AccountManagement");

		if (logger.isInfoEnabled()) {
			logger.info("the url for request" + url);
		}
		ManagePostPaidGrpResponse response= null;
		AccountManagementBindingStub stub=null;
		try{
			stub= new AccountManagementBindingStub(new URL(url),new AccountServiceLocator());
			SOAPHeaderElement header = Utilities.getSoapHeader(headerDetails);
			stub.setHeader(header);
			stub.setTimeout(Integer.parseInt(InitiateAll.getSMFProps().getProperty("iba.timeout")));
			
			response=stub.managePostPaidGrp(request);
			
			if (response != null) {
				if (logger.isInfoEnabled()) {
					logger.log(BCGLevel.INFO,
							">>>Response from  ManagePostPaidGrpInvoker---> managePostPaidGrp api Messsage  : "
									+ response.getMessage());
					endTime = System.currentTimeMillis();
					logger.log(BCGLevel.INFO,
							" ManagePostPaidGrpInvoker--->managePostPaidGrp()  Success:"
									+ (int) (endTime - startTime) + "ms");
				}
			} else {
				logger.log(BCGLevel.ERROR,
						"No response from IBA for ManagePostPaidGrpInvoker---> ManagePostPaidGrp api..");
				endTime = System.currentTimeMillis();
				logger.log(BCGLevel.INFO,
						" ManagePostPaidGrpInvoker--->ManagePostPaidGrp Failure:"
								+ (int) (endTime - startTime) + "ms");
				throw new SMFAgentException(SMFAgentConstants.INTERNAL_ERROR_CODE_STR, null);
			}
			
		}
		
		catch (AxisFault e) {
			logger.log(BCGLevel.ERROR, "ManagePostPaidGrp - AxisFault :"+Utilities.getStackTrace(e));
			endTime = System.currentTimeMillis();
			logger.log(BCGLevel.INFO,"ManagePostPaidGrp Failure:"+(int) (endTime - startTime)+"ms");
			throw new SMFAgentException(SMFAgentConstants.INTERNAL_ERROR_CODE_STR, null);
			}
			catch (RemoteException e) {
			logger.log(BCGLevel.ERROR, "ManagePostPaidGrp - RemoteException:"+Utilities.getStackTrace(e));
			endTime = System.currentTimeMillis();
			logger.log(BCGLevel.INFO,"ManagePostPaidGrp Failure:"+(int) (endTime - startTime)+"ms");
			throw new SMFAgentException(SMFAgentConstants.INTERNAL_ERROR_CODE_STR, null);
			}
			catch (MalformedURLException e) {
			logger.log(BCGLevel.ERROR, "ManagePostPaidGrp - MalformedURLException :"+Utilities.getStackTrace(e));
			endTime = System.currentTimeMillis();
			logger.log(BCGLevel.INFO,"createCAGRP Failure:"+(int) (endTime - startTime)+"ms");
			throw new SMFAgentException(SMFAgentConstants.INTERNAL_ERROR_CODE_STR, null);
			}
			return response;
		}

    	
    }


