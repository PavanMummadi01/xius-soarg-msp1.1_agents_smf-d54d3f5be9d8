package com.xius.smf.domaindata;


public class ViewBlkCorpRCDetailsRefCursorData {
	
	private String corp_rct_details;

	public String getCorp_rct_details() {
		return corp_rct_details;
	}

	public void setCorp_rct_details(String corp_rct_details) {
		this.corp_rct_details = corp_rct_details;
	}

	@Override
	public String toString() {
		return "ViewBlkCorpRCDetailsRefCursorData [corp_rct_details="
				+ corp_rct_details + "]";
	}

	
	
}
