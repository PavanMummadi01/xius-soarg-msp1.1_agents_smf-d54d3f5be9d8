package com.xius.smf.job;

import java.util.concurrent.CountDownLatch;

import net.bcgi.common.jmon.monitor.BCGLogger;

import com.xius.smf.domaindata.VOLTECursorData;
import com.xius.smf.domaindata.VolteInsertData;
import com.xius.smf.domaindata.VolteUpdateData;
import com.xius.smf.exceptions.SMFAgentException;
import com.xius.smf.utils.HeaderDetails;
import com.xius.smf.utils.InitiateAll;
import com.xius.smf.utils.SMFAgentConstants;
import com.xius.smf.utils.Utilities;
import com.xius.smf.webservices.smfservices.VolteProcessImpl;
import com.xius.tia.TTprovisioning_xsd.VolteDeProvisionRequest;
import com.xius.tia.TTprovisioning_xsd.VolteDeProvisionResponse;

public class VOLTEDeProvisionProcessor implements Runnable {
	private static final BCGLogger logger = BCGLogger
			.getBCGLogger(VOLTEDeProvisionProcessor.class.getSimpleName());

	CountDownLatch latch = null;
	VOLTECursorData cursorData = null;
	VolteInsertData InsertData = new VolteInsertData();
	VolteUpdateData Updateddata = new VolteUpdateData();
	VOLTEUpdateProcessor updateProcessor = new VOLTEUpdateProcessor();
	VOLTEInsertProcessor insertProcessor = new VOLTEInsertProcessor();
	String nwId = InitiateAll.getSMFProps()
	.getProperty(SMFAgentConstants.VOLTE_EXTERNAL_NW_ID);

	public VOLTEDeProvisionProcessor(CountDownLatch latch, VOLTECursorData curData) {
		this.latch = latch;
		this.cursorData = curData;
	}

	public VOLTEDeProvisionProcessor(VOLTECursorData curData) {
		this.cursorData = curData;
	}
	public void run() {
		logger.debug(">>>>> VolteDeProvisionProcessor run called ...");
		try {
			callProvisionVOLTE();
		} finally {
			if (latch != null)
				latch.countDown();
		}
	}

	public void callProvisionVOLTE() {

		logger.debug(">>>>> VolteDeProvisionProcessor callProvisionVOLTE called ...");
		try {

			HeaderDetails headerDetails = new HeaderDetails();

			headerDetails.setLoginID("SMFJob");
			if (cursorData != null)
				headerDetails.setNetworkID(cursorData.getNetwork_id());
			headerDetails.setPassword("11111111");

			VolteProcessImpl volteImpl = new VolteProcessImpl();

			VolteDeProvisionRequest request = new VolteDeProvisionRequest();
			VolteDeProvisionResponse response = null;

			if (cursorData != null) {

				// Insert Data Setting
				if(nwId!=null){
					InsertData.setPi_network_id(Long.parseLong(nwId));
					Updateddata.setPi_network_id(Long.parseLong(nwId));
				}
				if (cursorData.getACCOUNT_TYPE() != null) {
					InsertData.setPi_acc_type(Long.parseLong(cursorData
							.getACCOUNT_TYPE()));
				}
				if (cursorData.getMsisdn_no() != null) {
					InsertData.setPi_msisdn_no(cursorData.getMsisdn_no());
				}
				 
				if (cursorData.getPROCESS_SEQ_NUMBER() != null) {
					InsertData.setPi_ext_transaction_id(cursorData
							.getPROCESS_SEQ_NUMBER() + "");
				}
				InsertData.setPi_channel_name("SMFJOB");
				InsertData.setPi_service_flag("D");
				InsertData.setPi_activity_id(99L);
				InsertData.setPi_login_id("SMFJOB");
			
				if(cursorData.getAccount_id()!=null)
					InsertData.setPi_account_id(cursorData.getAccount_id());
				if(cursorData.getSim_serial_no()!=null)
					InsertData.setPi_sim_serial_no(cursorData.getSim_serial_no());
				if(cursorData.getImsi()!=null)
					InsertData.setPi_imsi_no(cursorData.getImsi());
				if(cursorData.getImsi()!=null)
					InsertData.setPi_acct_status(cursorData.getNEW_STATUS());
			

				insertProcessor.statusInsert(InsertData);

				if (InsertData.getPo_intrnl_transaction_id() != null) {

					//setting update data
					
					Updateddata
							.setPi_trans_id(InsertData.getPo_intrnl_transaction_id());
					
					// setting tia request as insert success

					logger.debug(">>>>> Insert SMF is successfull sending TIA Provision Request");

					request.setChannelId("SMFJOB");

					if (cursorData.getMsisdn_no() != null) {
						request.setMSISDN(cursorData.getMsisdn_no().toString());
					}
					if (cursorData.getACCOUNT_TYPE() != null) {
						request.setServiceType(cursorData.getACCOUNT_TYPE());
					}
					if (cursorData.getPROCESS_SEQ_NUMBER() != null) {
						request.setTransID(cursorData.getPROCESS_SEQ_NUMBER()
								.toString());
					}

					response = volteImpl.deprovision(request, headerDetails);
					if (response != null) {

						if (response.getStatus() != null) {
							if (response.getStatus() != null
									&& (String.valueOf(response.getStatus())
											.equalsIgnoreCase(
													SMFAgentConstants.SUCCESS) || String
											.valueOf(response.getStatus())
											.equalsIgnoreCase(
													"successfully provisioned"))) {

								
								//setting update data
								
								Updateddata
										.setPi_status(SMFAgentConstants.SUCCESS);
								if(response.getResponseData()!=null){
									if(response.getResponseData().getRespdescription()!=null){
								 Updateddata.setPi_remarks(response.getResponseData().getRespdescription());
									}
								}
							} else {
								Updateddata
										.setPi_status(SMFAgentConstants.FAILURE);
								 
									if(response.getResponseData()!=null){
										if(response.getResponseData().getRespdescription()!=null){
									 Updateddata.setPi_remarks(response.getResponseData().getRespdescription());
									 if(response.getResponseData().getResponsecode()!=null){
										 Updateddata.setPi_remarks(response.getResponseData().getResponsecode()+"#"+response.getResponseData().getRespdescription());
									 }
										}								
										}

							}
						} else {
							Updateddata
									.setPi_status(SMFAgentConstants.FAILURE);
							if(response.getResponseData()!=null){
								if(response.getResponseData().getRespdescription()!=null){
							 Updateddata.setPi_remarks(response.getResponseData().getRespdescription());
								}
							}

						}
					} else {
						logger.debug(">>>>> VolteDeProvisionProcessor - TIA response received null ...");
					}

				} else {
					logger.debug(">>>>> VolteDeProvisionProcessor - Insert Data Failed ...");
				}

			} else {
				logger.debug(">>>>> VolteDeProvisionProcessor - CursorData  is Null ...");
			}
		} catch (SMFAgentException _exp) {

			logger.error("VolteDeProvisionProcessor - VolteDeProvisionResponse ---> SMFAgentException");
			Updateddata.setPi_status(SMFAgentConstants.FAILURE);
			logger.error(Utilities.getStackTrace(_exp));

		} catch (Exception _exp) {
			logger.error("VolteDeProvisionProcessor - VolteDeProvisionResponse ---> Exception");
			Updateddata.setPi_status(SMFAgentConstants.FAILURE);

			logger.error(Utilities.getStackTrace(_exp));
		} finally {

			try {
				if (Updateddata != null) {
					if(Updateddata.getPi_trans_id()!=null){
					updateProcessor.statusUpdate(Updateddata);
					}
				} else {
					logger.error("VolteDeProvisionProcessor -- updateProcessor -domainData is Null");
				}
			} catch (Exception e) {
				logger.error("VolteDeProvisionProcessor -- updateProcessor ---> Exception");
				logger.error(Utilities.getStackTrace(e));
			}

		}
	}
}
