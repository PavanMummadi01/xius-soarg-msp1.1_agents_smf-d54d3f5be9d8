package com.xius.smf.job;

import net.bcgi.common.jmon.monitor.BCGLevel;
import net.bcgi.common.jmon.monitor.BCGLogger;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import com.xius.smf.job.task.SubscriberBulkUploadTask;
import com.xius.smf.utils.Utilities;

public class SubscriberBulkUploadJob implements Job {

	final BCGLogger logger = BCGLogger.getBCGLogger("SubscriberBulkUploadJob");
	public void execute(JobExecutionContext executionContext) throws JobExecutionException {
		
		try {
			
			logger.log(BCGLevel.INFO,"Executing SubscriberBulkUploadJob");
			
			SubscriberBulkUploadTask.doJob();
		} catch (Exception e) {

			logger.log(BCGLevel.ERROR,"Exception in execute() :"+Utilities.getStackTrace(e));
		} 
		
	}

}
