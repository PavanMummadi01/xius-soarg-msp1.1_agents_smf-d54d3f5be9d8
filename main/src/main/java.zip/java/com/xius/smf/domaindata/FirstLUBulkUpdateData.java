package com.xius.smf.domaindata;

public class FirstLUBulkUpdateData extends DomainDataBase{
	
	private String pi_iccid_from;
	private String pi_iccid_to;
	private long pi_nir_code;
	private String pi_office_Code;
	
	
	
	
	public String getPi_iccid_from() {
		return pi_iccid_from;
	}
	public void setPi_iccid_from(String pi_iccid_from) {
		this.pi_iccid_from = pi_iccid_from;
	}
	public String getPi_iccid_to() {
		return pi_iccid_to;
	}
	public void setPi_iccid_to(String pi_iccid_to) {
		this.pi_iccid_to = pi_iccid_to;
	}
	public long getPi_nir_code() {
		return pi_nir_code;
	}
	public void setPi_nir_code(long pi_nir_code) {
		this.pi_nir_code = pi_nir_code;
	}
	public String getPi_office_Code() {
		return pi_office_Code;
	}
	public void setPi_office_Code(String pi_office_Code) {
		this.pi_office_Code = pi_office_Code;
	}
	
	
	

}
