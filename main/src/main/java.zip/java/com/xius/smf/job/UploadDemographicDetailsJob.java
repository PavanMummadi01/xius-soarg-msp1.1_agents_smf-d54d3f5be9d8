package com.xius.smf.job;

import net.bcgi.common.jmon.monitor.BCGLevel;
import net.bcgi.common.jmon.monitor.BCGLogger;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.StatefulJob;

import com.xius.smf.job.task.UploadDemographicDetailsTask;
import com.xius.smf.utils.Utilities;

public class UploadDemographicDetailsJob implements Job , StatefulJob {

	//final BCGLogger logger = BCGLogger.getBCGLogger("UploadDemographicDetailsJob");
	final BCGLogger logger = BCGLogger.getBCGLogger(this.getClass().getName());
	
	public void execute(JobExecutionContext executionContext) throws JobExecutionException {
		
		long start = System.currentTimeMillis();
		
		logger.log(BCGLevel.INFO,"=========== UploadDemographicDetailsJob Started ===========");
		
		try {
			
			UploadDemographicDetailsTask task = new UploadDemographicDetailsTask();
			task.doJob();
		} catch (Exception e) {

			logger.log(BCGLevel.ERROR,"Exception in UploadDemographicDetailsJob execute() :" + Utilities.getStackTrace(e));
		} 
		
		logger.log(BCGLevel.INFO,"=========== UploadDemographicDetailsJob Ended ===========");
		
		logger.log(BCGLevel.INFO,"### ### ### Total Time taken to execute UploadDemographicDetailsJob in (milli secons): " + (System.currentTimeMillis() - start)  );
	}

}
