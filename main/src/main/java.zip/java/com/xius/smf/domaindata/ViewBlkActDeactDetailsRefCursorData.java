package com.xius.smf.domaindata;


public class ViewBlkActDeactDetailsRefCursorData {
	
	private String deact_react_details;

	
	public String getDeact_react_details() {
		return deact_react_details;
	}


	public void setDeact_react_details(String deact_react_details) {
		this.deact_react_details = deact_react_details;
	}


	@Override
	public String toString() {
		return "ViewBlkActDeactDetailsRefCursorData [deact_react_details="
				+ deact_react_details + "]";
	}


}
