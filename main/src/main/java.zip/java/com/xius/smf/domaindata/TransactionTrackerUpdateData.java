package com.xius.smf.domaindata;

public class TransactionTrackerUpdateData extends SimRegistrationUpdateData{
private  String pi_activity_type;

public String getPi_activity_type() {
	return pi_activity_type;
}

public void setPi_activity_type(String pi_activity_type) {
	this.pi_activity_type = pi_activity_type;
}
}
