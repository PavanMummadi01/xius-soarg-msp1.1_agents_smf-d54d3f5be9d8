package com.xius.smf.domaindata;

public class PostPaidRegStatusRefCurData {
	
	private String status;
	private String  sim_serial_no;
	private Long msisdn_no;
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getSim_serial_no() {
		return sim_serial_no;
	}
	public void setSim_serial_no(String sim_serial_no) {
		this.sim_serial_no = sim_serial_no;
	}
	public Long getMsisdn_no() {
		return msisdn_no;
	}
	public void setMsisdn_no(Long msisdn_no) {
		this.msisdn_no = msisdn_no;
	}
	
	
}
